import React, { useState, useEffect, useRef } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../store/AuthContext.jsx'
import toast from 'react-hot-toast'
import './AuthPage.css'

export default function AuthPage() {
  const [params] = useSearchParams()
  const [tab, setTab] = useState(params.get('tab') === 'register' ? 'register' : 'login')
  const [form, setForm] = useState({ username: '', email: '', password: '' })
  const [loading, setLoading] = useState(false)
  const { login, register } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (tab === 'login') {
        await login(form.email, form.password)
        toast.success('Welcome back! 🚀')
      } else {
        if (!form.username || form.username.length < 3) {
          toast.error('Username must be at least 3 characters')
          setLoading(false)
          return
        }
        await register(form.username, form.email, form.password)
        toast.success('Account created! Welcome to CodeForge AI 🎉')
      }
      navigate('/dashboard')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const fillDemo = () => {
    setForm({ username: '', email: 'demo@codeforge.ai', password: 'demo1234' })
    setTab('login')
  }

  return (
    <div className="auth-page">
      <div className="auth-bg">
        <div className="auth-orb auth-orb-1" />
        <div className="auth-orb auth-orb-2" />
      </div>

      <div className="auth-card animate-fade-in">
        {/* Header */}
        <div className="auth-header">
          <div className="auth-logo">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M8 3L4 7l4 4M16 3l4 4-4 4M12 20V4" stroke="url(#ag)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              <defs>
                <linearGradient id="ag" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#7c3aed"/>
                  <stop offset="100%" stopColor="#06b6d4"/>
                </linearGradient>
              </defs>
            </svg>
          </div>
          <h1 className="auth-title">
            {tab === 'login' ? 'Welcome back' : 'Join CodeForge AI'}
          </h1>
          <p className="auth-subtitle">
            {tab === 'login' ? 'Sign in to your account' : 'Create your free account'}
          </p>
        </div>

        {/* Tabs */}
        <div className="auth-tabs">
          <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => setTab('login')}>Sign In</button>
          <button className={`auth-tab ${tab === 'register' ? 'active' : ''}`} onClick={() => setTab('register')}>Register</button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="auth-form">
          {tab === 'register' && (
            <div className="form-group">
              <label>Username</label>
              <input className="input" type="text" placeholder="devhero" required
                value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} />
            </div>
          )}
          <div className="form-group">
            <label>Email</label>
            <input className="input" type="email" placeholder="you@example.com" required
              value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input className="input" type="password" placeholder="••••••••" required minLength={6}
              value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          </div>

          <button type="submit" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: '0.5rem' }} disabled={loading}>
            {loading ? <><div className="spinner" /> Processing...</> : tab === 'login' ? '🚀 Sign In' : '✨ Create Account'}
          </button>
        </form>

        {/* Demo access */}
        <div className="auth-demo">
          <button className="btn btn-ghost" onClick={fillDemo} style={{ width: '100%', justifyContent: 'center' }}>
            🎯 Use Demo Account
          </button>
          <p className="demo-hint">demo@codeforge.ai / demo1234</p>
        </div>

        {/* Features */}
        <div className="auth-features">
          {['⚡ Real code execution', '🤖 AI code review', '👥 Live collaboration', '📊 Analytics dashboard'].map(f => (
            <span key={f} className="auth-feature">{f}</span>
          ))}
        </div>
      </div>
    </div>
  )
}
