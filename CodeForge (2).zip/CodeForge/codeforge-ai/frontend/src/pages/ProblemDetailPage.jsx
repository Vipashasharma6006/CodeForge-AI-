import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import Editor from '@monaco-editor/react'
import axios from 'axios'
import toast from 'react-hot-toast'
import ReactMarkdown from 'react-markdown'
import './ProblemDetailPage.css'

export default function ProblemDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [problem, setProblem] = useState(null)
  const [loading, setLoading] = useState(true)
  const [language, setLanguage] = useState('javascript')
  const [code, setCode] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState(null)
  const [tab, setTab] = useState('description') // description | results

  useEffect(() => {
    axios.get(`/api/problems/${id}`)
      .then(res => {
        setProblem(res.data)
        setCode(res.data.starterCode?.javascript || '')
      })
      .catch(() => navigate('/problems'))
      .finally(() => setLoading(false))
  }, [id])

  const handleLangChange = (lang) => {
    setLanguage(lang)
    setCode(problem?.starterCode?.[lang] || '')
  }

  const handleSubmit = async () => {
    if (!code.trim()) return toast.error('Write your solution first!')
    setSubmitting(true)
    setTab('results')
    setResult(null)
    try {
      const res = await axios.post(`/api/problems/${id}/submit`, { code, language })
      setResult(res.data)
      if (res.data.status === 'accepted') toast.success('🎉 Accepted! All test cases passed!')
      else toast.error('❌ Wrong Answer or Runtime Error')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Submission failed')
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'60vh'}}><div className="spinner" style={{width:40,height:40}} /></div>
  if (!problem) return null

  return (
    <div className="problem-detail">
      <div className="problem-layout">
        {/* Left — Description */}
        <div className="problem-left">
          <div className="problem-left-header">
            <button className="btn btn-ghost btn-sm" onClick={() => navigate('/problems')}>← Back</button>
            <div className="flex gap-2 items-center">
              <span className={`badge badge-${problem.difficulty.toLowerCase()}`}>{problem.difficulty}</span>
              <span className="problem-id">#{problem.id}</span>
            </div>
          </div>

          <div className="problem-title-area">
            <h1>{problem.title}</h1>
            <div className="problem-tags">
              {problem.tags.map(t => <span key={t} className="tag">{t}</span>)}
            </div>
          </div>

          <div className="problem-description">
            <ReactMarkdown>{problem.description}</ReactMarkdown>
          </div>

          {problem.examples?.length > 0 && (
            <div className="problem-examples">
              <h3>Examples</h3>
              {problem.examples.map((ex, i) => (
                <div key={i} className="example-block">
                  <div className="example-row"><span>Input:</span><code>{ex.input}</code></div>
                  <div className="example-row"><span>Output:</span><code>{ex.output}</code></div>
                  {ex.explanation && <div className="example-row"><span>Note:</span><span style={{color:'var(--text-muted)',fontSize:'0.82rem'}}>{ex.explanation}</span></div>}
                </div>
              ))}
            </div>
          )}

          {problem.constraints?.length > 0 && (
            <div className="problem-constraints">
              <h3>Constraints</h3>
              <ul>{problem.constraints.map((c, i) => <li key={i}><code>{c}</code></li>)}</ul>
            </div>
          )}
        </div>

        {/* Right — Editor */}
        <div className="problem-right">
          <div className="problem-editor-toolbar">
            <div className="lang-selector">
              {['javascript','python','cpp'].map(l => (
                <button key={l} className={`lang-btn ${language === l ? 'active' : ''}`} onClick={() => handleLangChange(l)}>
                  {l === 'javascript' ? 'JS' : l === 'python' ? 'Python' : 'C++'}
                </button>
              ))}
            </div>
            <button className="btn btn-primary" onClick={handleSubmit} disabled={submitting} id="submit-btn">
              {submitting ? <><div className="spinner" />Submitting...</> : '🚀 Submit'}
            </button>
          </div>

          <div className="problem-editor-body">
            <Editor
              height="100%"
              language={language}
              value={code}
              onChange={v => setCode(v || '')}
              theme="vs-dark"
              options={{ fontSize: 14, fontFamily: "'JetBrains Mono', monospace", minimap: { enabled: false }, automaticLayout: true, padding: { top: 12 }, scrollBeyondLastLine: false, tabSize: 2 }}
            />
          </div>

          {/* Result panel */}
          <div className="problem-result-panel">
            <div className="result-tabs">
              <button className={`result-tab ${tab === 'description' ? 'active' : ''}`} onClick={() => setTab('description')}>Test Cases</button>
              <button className={`result-tab ${tab === 'results' ? 'active' : ''}`} onClick={() => setTab('results')}>Results</button>
            </div>

            <div className="result-content">
              {tab === 'description' && (
                <div className="test-cases">
                  {problem.testCases?.length > 0 ? problem.testCases.map((tc, i) => (
                    <div key={i} className="test-case">
                      <span className="tc-num">Case {i+1}</span>
                      <code>{JSON.stringify(tc.input)}</code>
                      <span className="tc-arrow">→</span>
                      <code className="tc-expected">{JSON.stringify(tc.expected)}</code>
                    </div>
                  )) : (
                    <p style={{color:'var(--text-muted)',fontSize:'0.85rem',padding:'1rem'}}>Submit your solution to see test results.</p>
                  )}
                </div>
              )}

              {tab === 'results' && (
                <div className="submission-result">
                  {!result && !submitting && <p style={{color:'var(--text-muted)',fontSize:'0.85rem',padding:'1rem'}}>Submit your solution to see results.</p>}
                  {submitting && <div className="flex items-center gap-2" style={{padding:'1rem'}}><div className="spinner" /><span style={{color:'var(--text-muted)'}}>Running test cases...</span></div>}
                  {result && (
                    <>
                      <div className={`verdict ${result.status === 'accepted' ? 'accepted' : 'wrong'}`}>
                        {result.status === 'accepted' ? '✅ Accepted' : result.status === 'runtime_error' ? '❌ Runtime Error' : '❌ Wrong Answer'}
                        {result.total > 0 && <span className="verdict-cases">{result.passed}/{result.total} cases</span>}
                      </div>
                      {result.result?.stdout && <pre className="result-pre">{result.result.stdout}</pre>}
                      {result.result?.stderr && <pre className="result-pre error">{result.result.stderr}</pre>}
                      {result.testResults?.map((tr, i) => (
                        <div key={i} className={`test-result ${tr.passed ? 'pass' : 'fail'}`}>
                          <span>{tr.passed ? '✅' : '❌'} Case {i+1}</span>
                          {!tr.passed && <span className="tr-detail">Got: {tr.output} · Expected: {tr.expected}</span>}
                        </div>
                      ))}
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
