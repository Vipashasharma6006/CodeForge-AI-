import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts'
import './DashboardPage.css'

const COLORS = ['#7c3aed', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#ec4899']

export default function DashboardPage() {
  const [data, setData] = useState(null)
  const [leaderboard, setLeaderboard] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      axios.get('/api/analytics/me'),
      axios.get('/api/analytics/leaderboard')
    ]).then(([meRes, lbRes]) => {
      setData(meRes.data)
      setLeaderboard(lbRes.data)
    }).finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'60vh'}}>
      <div className="spinner" style={{width:40,height:40}} />
    </div>
  )

  if (!data) return null

  const langData = Object.entries(data.languageDistribution || {}).map(([name, value]) => ({ name, value }))
  const statusData = [
    { name: 'Accepted', value: data.statusDistribution?.accepted || 0, color: '#10b981' },
    { name: 'Wrong', value: data.statusDistribution?.wrong_answer || 0, color: '#ef4444' },
    { name: 'Error', value: data.statusDistribution?.runtime_error || 0, color: '#f59e0b' },
    { name: 'Run', value: data.statusDistribution?.run || 0, color: '#7c3aed' },
  ].filter(d => d.value > 0)

  const heatmapDays = generateHeatmap(data.heatmap || {})

  return (
    <div className="dashboard-page">
      <div className="container">
        <div className="dash-header">
          <div>
            <h1>Your <span className="gradient-text">Dashboard</span></h1>
            <p>Track your coding journey and progress</p>
          </div>
          <div className="user-profile-card">
            <div className="profile-avatar">{data.user.avatar}</div>
            <div>
              <div className="profile-name">{data.user.username}</div>
              <div className="profile-rank">Rank #{data.user.rank}</div>
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="stats-grid">
          {[
            { label: 'Problems Solved', value: data.stats.solved, icon: '✅', color: '#10b981' },
            { label: 'Total Submissions', value: data.stats.submissions, icon: '📤', color: '#7c3aed' },
            { label: 'Current Streak', value: `${data.stats.streak}d`, icon: '🔥', color: '#f59e0b' },
            { label: 'Acceptance Rate', value: `${data.stats.acceptanceRate}%`, icon: '🎯', color: '#06b6d4' },
          ].map(s => (
            <div key={s.label} className="stat-card glass-card">
              <div className="stat-icon" style={{ background: `${s.color}20` }}>{s.icon}</div>
              <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="dash-main">
          {/* Activity Heatmap */}
          <div className="heatmap-card glass-card">
            <h3>📅 Activity Heatmap</h3>
            <p className="card-subtitle">Submissions in the last 24 weeks</p>
            <div className="heatmap-grid">
              {heatmapDays.map((day, i) => (
                <div key={i} className="heatmap-cell"
                  style={{ background: day.count > 0 ? `rgba(124,58,237,${Math.min(0.2 + day.count * 0.2, 1)})` : 'rgba(255,255,255,0.03)' }}
                  title={`${day.date}: ${day.count} submissions`} />
              ))}
            </div>
            <div className="heatmap-legend">
              <span>Less</span>
              {[0.1, 0.3, 0.6, 0.9].map(o => <div key={o} style={{ background: `rgba(124,58,237,${o})`, width: 12, height: 12, borderRadius: 3 }} />)}
              <span>More</span>
            </div>
          </div>

          {/* Charts Row */}
          <div className="charts-row">
            {/* Language Pie */}
            <div className="chart-card glass-card">
              <h3>🌐 Languages Used</h3>
              {langData.length > 0 ? (
                <>
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie data={langData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={3}>
                        {langData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                      </Pie>
                      <Tooltip contentStyle={{ background: '#0f0f1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="lang-legend">
                    {langData.map((l, i) => (
                      <div key={l.name} className="lang-legend-item">
                        <div className="lang-dot" style={{ background: COLORS[i % COLORS.length] }} />
                        <span>{l.name}</span>
                        <span className="lang-count">{l.value}</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="chart-empty">Run some code to see language stats</div>
              )}
            </div>

            {/* Status Distribution */}
            <div className="chart-card glass-card">
              <h3>📊 Submission Status</h3>
              {statusData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={statusData} margin={{ top: 10, right: 10, bottom: 10, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 11 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: '#0f0f1a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: '#f1f5f9' }} />
                    <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                      {statusData.map((s, i) => <Cell key={i} fill={s.color} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="chart-empty">Submit solutions to see statistics</div>
              )}
            </div>
          </div>

          {/* Recent Submissions + Leaderboard */}
          <div className="bottom-row">
            <div className="recent-card glass-card">
              <h3>🕐 Recent Submissions</h3>
              {data.recentSubmissions.length === 0 ? (
                <div className="chart-empty">No submissions yet. Start solving!</div>
              ) : (
                <div className="recent-list">
                  {data.recentSubmissions.map(s => (
                    <div key={s.id} className="recent-item">
                      <div className="recent-info">
                        <span className="recent-problem">{s.problemTitle}</span>
                        <span className="recent-lang">{s.language}</span>
                      </div>
                      <div className="recent-right">
                        {s.runtime && <span className="recent-time">{s.runtime}ms</span>}
                        <span className={`badge badge-${s.status === 'accepted' ? 'success' : s.status === 'run' ? 'info' : 'error'}`}>
                          {s.status === 'accepted' ? 'Accepted' : s.status === 'run' ? 'Run' : 'Failed'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="leaderboard-card glass-card">
              <h3>🏆 Leaderboard</h3>
              <div className="lb-list">
                {leaderboard.slice(0, 8).map((u, i) => (
                  <div key={u.id} className={`lb-row ${i < 3 ? 'top-three' : ''}`}>
                    <span className="lb-rank">
                      {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i+1}`}
                    </span>
                    <div className="lb-avatar">{u.avatar}</div>
                    <span className="lb-name">{u.username}</span>
                    <span className="lb-solved">{u.solved} solved</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function generateHeatmap(heatmapData) {
  const days = []
  const now = new Date()
  for (let i = 167; i >= 0; i--) {
    const d = new Date(now)
    d.setDate(d.getDate() - i)
    const dateStr = d.toISOString().slice(0, 10)
    days.push({ date: dateStr, count: heatmapData[dateStr] || 0 })
  }
  return days
}
