import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { io } from 'socket.io-client'
import Editor from '@monaco-editor/react'
import { useAuth } from '../store/AuthContext.jsx'
import axios from 'axios'
import toast from 'react-hot-toast'
import './CollabPage.css'

const LANGUAGES = ['javascript', 'python', 'cpp', 'java', 'go']

export default function CollabPage() {
  const { roomId: paramRoomId } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [connected, setConnected] = useState(false)
  const [roomId, setRoomId] = useState(paramRoomId || '')
  const [joinInput, setJoinInput] = useState('')
  const [joined, setJoined] = useState(false)
  const [participants, setParticipants] = useState([])
  const [code, setCode] = useState('// Collaborative workspace — code together in real time!\n\nfunction hello() {\n  console.log("Hello from CodeForge Collab!");\n}\n\nhello();')
  const [language, setLanguage] = useState('javascript')
  const [messages, setMessages] = useState([])
  const [chatInput, setChatInput] = useState('')
  const [output, setOutput] = useState(null)
  const [running, setRunning] = useState(false)
  const [showChat, setShowChat] = useState(true)
  const socketRef = useRef(null)
  const codeRef = useRef(code)
  const messagesEndRef = useRef(null)
  const isRemoteChange = useRef(false)

  useEffect(() => {
    const socket = io('/', { transports: ['websocket', 'polling'] })
    socketRef.current = socket

    socket.on('connect', () => { setConnected(true); if (paramRoomId) joinRoom(paramRoomId, socket) })
    socket.on('disconnect', () => setConnected(false))
    socket.on('room:joined', ({ roomId: rid, code: c, language: l, participants: p, messages: m }) => {
      setRoomId(rid)
      setCode(c); codeRef.current = c
      setLanguage(l)
      setParticipants(p)
      setMessages(m || [])
      setJoined(true)
      if (!paramRoomId) navigate(`/collab/${rid}`, { replace: true })
      toast.success(`Joined room ${rid}`)
    })
    socket.on('room:participants', setParticipants)
    socket.on('room:participant_joined', (p) => toast(`${p.username} joined the room`))
    socket.on('room:participant_left', (p) => toast(`${p.username} left the room`))
    socket.on('code:change', ({ code: c }) => { isRemoteChange.current = true; setCode(c); codeRef.current = c })
    socket.on('language:change', ({ language: l, changedBy }) => { setLanguage(l); toast(`${changedBy} switched to ${l}`) })
    socket.on('chat:message', (msg) => setMessages(m => [...m, msg]))
    socket.on('execution:result', ({ stdout, stderr, runtime, executedBy }) => {
      setOutput({ stdout, stderr, runtime }); toast(`${executedBy} ran the code`)
    })

    return () => socket.disconnect()
  }, [])

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const joinRoom = (rid, socket) => {
    const s = socket || socketRef.current
    if (!s) return
    s.emit('room:join', { roomId: rid || undefined, username: user.username, avatar: user.avatar })
  }

  const handleJoin = () => {
    if (!connected) return toast.error('Not connected to server')
    joinRoom(joinInput.trim().toUpperCase() || undefined)
  }

  const handleCodeChange = useCallback((val) => {
    if (isRemoteChange.current) { isRemoteChange.current = false; return }
    const newCode = val || ''
    setCode(newCode)
    codeRef.current = newCode
    socketRef.current?.emit('code:change', { code: newCode, language })
  }, [language])

  const handleLangChange = (lang) => {
    setLanguage(lang)
    socketRef.current?.emit('language:change', { language: lang })
  }

  const runCode = async () => {
    setRunning(true)
    try {
      const res = await axios.post('/api/code/run', { code: codeRef.current, language })
      setOutput(res.data)
      socketRef.current?.emit('execution:result', res.data)
    } catch (err) {
      setOutput({ stdout: '', stderr: err.response?.data?.error || 'Execution failed', runtime: 0 })
    } finally { setRunning(false) }
  }

  const sendChat = () => {
    if (!chatInput.trim()) return
    socketRef.current?.emit('chat:message', { message: chatInput.trim() })
    setChatInput('')
  }

  if (!joined) {
    return (
      <div className="collab-join-page">
        <div className="collab-join-bg"><div className="collab-orb-1" /><div className="collab-orb-2" /></div>
        <div className="collab-join-card animate-fade-in">
          <div className="cj-icon">👥</div>
          <h2>Real-time Collaboration</h2>
          <p>Create a new room or join an existing one to code together in real time.</p>
          <div className={`conn-status ${connected ? 'connected' : 'disconnected'}`}>
            <span className="conn-dot" />{connected ? 'Connected to server' : 'Connecting...'}
          </div>
          <div className="cj-actions">
            <button className="btn btn-primary" onClick={() => handleJoin()} disabled={!connected}>
              ✨ Create New Room
            </button>
            <div className="cj-or"><span>or join existing</span></div>
            <div className="flex gap-2">
              <input className="input" placeholder="Room ID (e.g. ABC12345)"
                value={joinInput} onChange={e => setJoinInput(e.target.value.toUpperCase())}
                onKeyDown={e => e.key === 'Enter' && handleJoin()} maxLength={8} />
              <button className="btn btn-secondary" onClick={() => handleJoin()} disabled={!connected || !joinInput.trim()}>Join</button>
            </div>
          </div>
          <div className="cj-features">
            {['🔄 Real-time sync', '👁️ Live cursors', '💬 Room chat', '⚡ Run & share output'].map(f => (
              <span key={f} className="cj-feature">{f}</span>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="collab-page">
      {/* Toolbar */}
      <div className="collab-toolbar">
        <div className="collab-toolbar-left">
          <span className="room-id-badge">🔗 Room: <strong>{roomId}</strong></span>
          <div className="participants-row">
            {participants.map(p => (
              <div key={p.id} className="participant-dot" title={p.username}
                style={{ background: p.color || 'var(--accent-primary)' }}>
                {p.avatar || p.username.slice(0, 2).toUpperCase()}
              </div>
            ))}
            <span className="participant-count">{participants.length} online</span>
          </div>
          <select className="lang-select" value={language} onChange={e => handleLangChange(e.target.value)}>
            {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div className="collab-toolbar-right">
          <button className="btn btn-ghost btn-sm" onClick={() => { navigator.clipboard.writeText(roomId); toast.success('Room ID copied!') }}>📋 Copy ID</button>
          <button className="btn btn-secondary btn-sm" onClick={() => setShowChat(!showChat)}>{showChat ? '💬 Hide Chat' : '💬 Chat'}</button>
          <button className="btn btn-primary" onClick={runCode} disabled={running}>
            {running ? <><div className="spinner" />Running...</> : '▶ Run & Share'}
          </button>
        </div>
      </div>

      {/* Main */}
      <div className={`collab-layout ${showChat ? 'with-chat' : ''}`}>
        <div className="collab-editor-pane">
          <Editor height="100%" language={language} value={code} onChange={handleCodeChange} theme="vs-dark"
            options={{ fontSize: 14, fontFamily: "'JetBrains Mono', monospace", minimap: { enabled: false }, automaticLayout: true, padding: { top: 12 }, scrollBeyondLastLine: false, tabSize: 2 }} />
        </div>

        {showChat && (
          <div className="collab-sidebar">
            <div className="sidebar-tabs-header">
              <span className="sidebar-tab active">💬 Chat</span>
              {output && <span className="sidebar-tab" style={{marginLeft:'auto',color:'var(--accent-green)'}}>⚡ Output ready</span>}
            </div>
            {output && (
              <div className="collab-output">
                <div className="output-mini-bar">
                  <span className={output.exitCode === 0 ? 'out-success' : 'out-error'}>{output.exitCode === 0 ? '✅' : '❌'} {output.runtime}ms</span>
                </div>
                {output.stdout && <pre className="output-pre-mini">{output.stdout}</pre>}
                {output.stderr && <pre className="output-pre-mini error">{output.stderr}</pre>}
              </div>
            )}
            <div className="chat-messages-collab">
              {messages.map((m, i) => (
                <div key={i} className={`collab-msg ${m.username === user.username ? 'own' : ''}`}>
                  {m.username !== user.username && <div className="collab-msg-user">{m.avatar || m.username.slice(0,2)}</div>}
                  <div className="collab-msg-content">
                    {m.username !== user.username && <span className="collab-msg-name">{m.username}</span>}
                    <div className="collab-msg-bubble">{m.message}</div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <div className="collab-chat-input">
              <input className="input" placeholder="Message the room..." value={chatInput}
                onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendChat()} />
              <button className="btn btn-primary btn-sm" onClick={sendChat}>Send</button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
