import React, { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../store/AuthContext.jsx'
import './HomePage.css'

const FEATURES = [
  {
    icon: '⚡',
    title: 'Instant Execution',
    desc: 'Run JavaScript, Python, C++, Java & Go in isolated sandboxes. Sub-second results with output streaming.',
    color: '#7c3aed'
  },
  {
    icon: '🤖',
    title: 'AI Code Review',
    desc: 'Get instant AI-powered reviews, debugging help, optimization suggestions and code explanations.',
    color: '#06b6d4'
  },
  {
    icon: '👥',
    title: 'Real-time Collaboration',
    desc: 'Code with teammates simultaneously. See live cursors, sync edits, and chat — all in one room.',
    color: '#10b981'
  },
  {
    icon: '🧩',
    title: 'Coding Challenges',
    desc: 'LeetCode-style problems with Easy/Medium/Hard levels, test cases, and instant feedback.',
    color: '#f59e0b'
  },
  {
    icon: '📊',
    title: 'Analytics Dashboard',
    desc: 'Track your progress with submission heatmaps, language distribution charts, and ranking.',
    color: '#ec4899'
  },
  {
    icon: '🔐',
    title: 'Secure Auth',
    desc: 'JWT-based authentication with bcrypt password hashing, rate limiting, and session management.',
    color: '#f97316'
  }
]

const STATS = [
  { value: '6+', label: 'Problems' },
  { value: '5', label: 'Languages' },
  { value: '∞', label: 'Executions' },
  { value: '🤖', label: 'AI Powered' }
]

const CODE_DEMO = `function twoSum(nums, target) {
  const map = new Map();
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (map.has(complement)) {
      return [map.get(complement), i];
    }
    map.set(nums[i], i);
  }
}

console.log(twoSum([2,7,11,15], 9));
// Output: [0, 1] ✓  Runtime: 2ms`

export default function HomePage() {
  const { user } = useAuth()
  const heroRef = useRef(null)

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (!heroRef.current) return
      const { clientX, clientY } = e
      const { innerWidth, innerHeight } = window
      const x = (clientX / innerWidth - 0.5) * 20
      const y = (clientY / innerHeight - 0.5) * 20
      heroRef.current.style.setProperty('--mx', `${x}px`)
      heroRef.current.style.setProperty('--my', `${y}px`)
    }
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  return (
    <div className="home">
      {/* ── Hero ── */}
      <section className="hero" ref={heroRef}>
        <div className="hero-bg">
          <div className="hero-orb hero-orb-1" />
          <div className="hero-orb hero-orb-2" />
          <div className="hero-grid" />
        </div>

        <div className="hero-content">
          <div className="hero-badge animate-fade-in">
            <span className="hero-badge-dot" />
            AI-Powered · Real-time · Production-Level
          </div>

          <h1 className="hero-title animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Code. Execute.
            <br />
            <span className="gradient-text">Collaborate with AI.</span>
          </h1>

          <p className="hero-subtitle animate-fade-in" style={{ animationDelay: '0.2s' }}>
            A distributed platform combining the best of Replit, LeetCode, and GitHub —
            with AI-powered code review, sandboxed execution, and real-time collaboration.
          </p>

          <div className="hero-actions animate-fade-in" style={{ animationDelay: '0.3s' }}>
            {user ? (
              <>
                <Link to="/ide" className="btn btn-primary btn-xl">🚀 Open IDE</Link>
                <Link to="/problems" className="btn btn-secondary btn-xl">🧩 Problems</Link>
              </>
            ) : (
              <>
                <Link to="/auth?tab=register" className="btn btn-primary btn-xl">✨ Get Started Free</Link>
                <Link to="/problems" className="btn btn-secondary btn-xl">🧩 Browse Problems</Link>
              </>
            )}
          </div>

          {/* Stats */}
          <div className="hero-stats animate-fade-in" style={{ animationDelay: '0.4s' }}>
            {STATS.map(s => (
              <div key={s.label} className="hero-stat">
                <span className="hero-stat-value">{s.value}</span>
                <span className="hero-stat-label">{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Code preview */}
        <div className="hero-code animate-fade-in" style={{ animationDelay: '0.5s' }}>
          <div className="code-window">
            <div className="code-window-bar">
              <span className="dot dot-red" />
              <span className="dot dot-yellow" />
              <span className="dot dot-green" />
              <span className="code-window-title">two-sum.js — CodeForge AI</span>
            </div>
            <pre className="code-body"><code>{CODE_DEMO}</code></pre>
            <div className="code-output">
              <span className="output-label">▶ Output</span>
              <span className="output-text">[0, 1]</span>
              <span className="output-meta">Runtime: 2ms · Memory: 3.1MB ✓</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section className="features-section">
        <div className="container">
          <div className="section-header">
            <h2>Everything you need to <span className="gradient-text">level up</span></h2>
            <p>A production-grade platform showcasing distributed systems, AI integration, and real-time architecture.</p>
          </div>

          <div className="features-grid">
            {FEATURES.map((f, i) => (
              <div key={f.title} className="feature-card glass-card animate-fade-in"
                style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="feature-icon" style={{ background: `${f.color}20`, borderColor: `${f.color}30` }}>
                  <span style={{ fontSize: '1.5rem' }}>{f.icon}</span>
                </div>
                <h3 className="feature-title">{f.title}</h3>
                <p className="feature-desc">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Architecture ── */}
      <section className="arch-section">
        <div className="container">
          <div className="section-header">
            <h2>Production <span className="gradient-text">Architecture</span></h2>
            <p>Built with recruiter conversations in mind — every layer demonstrates a key engineering skill.</p>
          </div>

          <div className="arch-grid">
            {[
              { layer: 'Frontend', tech: 'React + Vite + Monaco Editor', skill: 'Full Stack', color: '#7c3aed' },
              { layer: 'API Gateway', tech: 'Node.js + Express + Socket.IO', skill: 'Backend APIs', color: '#06b6d4' },
              { layer: 'Auth', tech: 'JWT + bcrypt + Rate Limiting', skill: 'Security', color: '#10b981' },
              { layer: 'Job Queue', tech: 'In-memory Queue (BullMQ-ready)', skill: 'Async Systems', color: '#f59e0b' },
              { layer: 'Execution', tech: 'Process sandbox + vm module', skill: 'DevOps', color: '#ef4444' },
              { layer: 'Database', tech: 'LowDB (MongoDB-ready)', skill: 'Data Layer', color: '#ec4899' },
              { layer: 'AI Layer', tech: 'Gemini API (demo fallback)', skill: 'AI/ML', color: '#f97316' },
              { layer: 'WebSocket', tech: 'Socket.IO collab rooms', skill: 'Real-time', color: '#a855f7' },
            ].map((a) => (
              <div key={a.layer} className="arch-card">
                <div className="arch-layer" style={{ color: a.color }}>{a.layer}</div>
                <div className="arch-tech">{a.tech}</div>
                <span className="badge badge-purple">{a.skill}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="cta-section">
        <div className="cta-inner">
          <div className="cta-orb" />
          <h2>Ready to start coding?</h2>
          <p>Join CodeForge AI and experience the future of collaborative, AI-powered development.</p>
          <div className="flex gap-4 justify-center" style={{ flexWrap: 'wrap' }}>
            {user ? (
              <Link to="/ide" className="btn btn-primary btn-xl animate-glow">🚀 Launch IDE</Link>
            ) : (
              <Link to="/auth?tab=register" className="btn btn-primary btn-xl animate-glow">✨ Start Coding Now</Link>
            )}
            <Link to="/problems" className="btn btn-secondary btn-xl">🧩 View Problems</Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="footer-inner">
            <span className="logo-text">CodeForge <span className="logo-ai">AI</span></span>
            <span className="footer-copy">Built with ❤️ — Distributed AI Code Platform</span>
            <div className="footer-links">
              <Link to="/problems">Problems</Link>
              <Link to="/ide">IDE</Link>
              <Link to="/collab">Collaborate</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
