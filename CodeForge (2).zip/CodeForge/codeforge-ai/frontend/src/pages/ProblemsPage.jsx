import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import './ProblemsPage.css'

const DIFFICULTIES = ['All', 'Easy', 'Medium', 'Hard']

export default function ProblemsPage() {
  const [problems, setProblems] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState({ difficulty: '', search: '' })
  const [stats, setStats] = useState({ easy: 0, medium: 0, hard: 0 })

  useEffect(() => {
    fetchProblems()
  }, [filter])

  const fetchProblems = async () => {
    setLoading(true)
    try {
      const params = {}
      if (filter.difficulty && filter.difficulty !== 'All') params.difficulty = filter.difficulty
      if (filter.search) params.search = filter.search
      const res = await axios.get('/api/problems', { params })
      setProblems(res.data.problems || [])
      // Calculate stats
      const all = res.data.problems || []
      setStats({
        easy: all.filter(p => p.difficulty === 'Easy').length,
        medium: all.filter(p => p.difficulty === 'Medium').length,
        hard: all.filter(p => p.difficulty === 'Hard').length,
      })
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const difficultyClass = (d) => d.toLowerCase()

  return (
    <div className="problems-page">
      <div className="container">
        {/* Header */}
        <div className="problems-header">
          <div>
            <h1>Coding <span className="gradient-text">Problems</span></h1>
            <p>Practice with curated challenges. Track your progress and get AI-powered hints.</p>
          </div>
          <div className="problems-stats">
            <div className="pstat easy"><span>{stats.easy}</span>Easy</div>
            <div className="pstat medium"><span>{stats.medium}</span>Medium</div>
            <div className="pstat hard"><span>{stats.hard}</span>Hard</div>
          </div>
        </div>

        {/* Filters */}
        <div className="problems-filters">
          <input
            className="input"
            style={{ maxWidth: 320 }}
            placeholder="🔍 Search problems..."
            value={filter.search}
            onChange={e => setFilter({ ...filter, search: e.target.value })}
          />
          <div className="diff-filters">
            {DIFFICULTIES.map(d => (
              <button key={d}
                className={`diff-btn ${(filter.difficulty === d || (!filter.difficulty && d === 'All')) ? 'active' : ''} ${d !== 'All' ? d.toLowerCase() : ''}`}
                onClick={() => setFilter({ ...filter, difficulty: d === 'All' ? '' : d })}>
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="problems-table">
          <div className="table-header">
            <span className="col-status">Status</span>
            <span className="col-title">Title</span>
            <span className="col-tags hide-mobile">Tags</span>
            <span className="col-diff">Difficulty</span>
            <span className="col-acc hide-mobile">Acceptance</span>
            <span className="col-action">Action</span>
          </div>

          {loading ? (
            <div className="table-loading">
              {[1,2,3,4,5,6].map(i => <div key={i} className="skeleton-row" />)}
            </div>
          ) : problems.length === 0 ? (
            <div className="table-empty">
              <span>🔍</span>
              <p>No problems found. Try adjusting your filters.</p>
            </div>
          ) : (
            problems.map((p, i) => (
              <div key={p.id} className="table-row animate-fade-in" style={{ animationDelay: `${i * 0.05}s` }}>
                <span className="col-status">
                  {p.solved ? '✅' : <span className="unsolved-dot" />}
                </span>
                <span className="col-title">
                  <Link to={`/problems/${p.id}`} className="problem-title-link">
                    {p.id}. {p.title}
                  </Link>
                </span>
                <span className="col-tags hide-mobile">
                  <div className="tags-list">
                    {p.tags.slice(0, 2).map(t => <span key={t} className="tag">{t}</span>)}
                    {p.tags.length > 2 && <span className="tag">+{p.tags.length - 2}</span>}
                  </div>
                </span>
                <span className="col-diff">
                  <span className={`badge badge-${difficultyClass(p.difficulty)}`}>{p.difficulty}</span>
                </span>
                <span className="col-acc hide-mobile">
                  <span className="acceptance">{p.acceptance}%</span>
                </span>
                <span className="col-action">
                  <Link to={`/problems/${p.id}`} className="btn btn-primary btn-sm">Solve</Link>
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
