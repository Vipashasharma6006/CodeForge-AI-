import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../store/AuthContext.jsx'
import './Navbar.css'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/')

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        {/* Logo */}
        <Link to="/" className="navbar-logo">
          <div className="logo-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M8 3L4 7l4 4M16 3l4 4-4 4M12 20V4" stroke="url(#ng)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              <defs>
                <linearGradient id="ng" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#7c3aed"/>
                  <stop offset="100%" stopColor="#06b6d4"/>
                </linearGradient>
              </defs>
            </svg>
          </div>
          <span className="logo-text">CodeForge <span className="logo-ai">AI</span></span>
        </Link>

        {/* Nav Links */}
        <div className="navbar-links hide-mobile">
          <Link to="/problems" className={`nav-link ${isActive('/problems') ? 'active' : ''}`}>Problems</Link>
          {user && <Link to="/ide" className={`nav-link ${isActive('/ide') ? 'active' : ''}`}>IDE</Link>}
          {user && <Link to="/collab" className={`nav-link ${isActive('/collab') ? 'active' : ''}`}>Collaborate</Link>}
          {user && <Link to="/dashboard" className={`nav-link ${isActive('/dashboard') ? 'active' : ''}`}>Dashboard</Link>}
        </div>

        {/* Right side */}
        <div className="navbar-right">
          {user ? (
            <div className="user-menu">
              <div className="user-avatar" onClick={() => setMenuOpen(!menuOpen)}>
                <span>{user.avatar}</span>
              </div>
              <span className="user-name hide-mobile">{user.username}</span>
              {menuOpen && (
                <div className="dropdown">
                  <div className="dropdown-header">
                    <strong>{user.username}</strong>
                    <span>{user.email}</span>
                  </div>
                  <Link to="/dashboard" className="dropdown-item" onClick={() => setMenuOpen(false)}>📊 Dashboard</Link>
                  <Link to="/ide" className="dropdown-item" onClick={() => setMenuOpen(false)}>💻 IDE</Link>
                  <Link to="/collab" className="dropdown-item" onClick={() => setMenuOpen(false)}>👥 Collaborate</Link>
                  <div className="dropdown-divider" />
                  <button className="dropdown-item danger" onClick={handleLogout}>🚪 Sign Out</button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex gap-2">
              <Link to="/auth" className="btn btn-ghost btn-sm">Sign In</Link>
              <Link to="/auth?tab=register" className="btn btn-primary btn-sm">Get Started</Link>
            </div>
          )}
        </div>
      </div>
      {menuOpen && <div className="dropdown-backdrop" onClick={() => setMenuOpen(false)} />}
    </nav>
  )
}
