import 'dotenv/config'
import express from 'express'
import { createServer } from 'http'
import { Server } from 'socket.io'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import { rateLimit } from 'express-rate-limit'

import { initDB } from './src/config/db.js'
import { initExecutionService } from './src/services/executionService.js'
import { executionQueue } from './src/services/queueService.js'
import { executeCode } from './src/services/executionService.js'
import { setupCollaboration } from './src/socket/collaborationHandler.js'

import authRoutes from './src/routes/auth.js'
import codeRoutes from './src/routes/code.js'
import problemsRoutes from './src/routes/problems.js'
import aiRoutes from './src/routes/ai.js'
import analyticsRoutes from './src/routes/analytics.js'

const app = express()
const httpServer = createServer(app)
const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
})

const PORT = process.env.PORT || 5000

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors())
app.use(helmet({ contentSecurityPolicy: false }))
app.use(morgan('dev'))
app.use(express.json({ limit: '2mb' }))

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true })
app.use('/api/', limiter)

const executionLimiter = rateLimit({ windowMs: 60 * 1000, max: 20 })
app.use('/api/code/', executionLimiter)

// ─── Routes ──────────────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes)
app.use('/api/code', codeRoutes)
app.use('/api/problems', problemsRoutes)
app.use('/api/ai', aiRoutes)
app.use('/api/analytics', analyticsRoutes)

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    platform: 'CodeForge AI',
    aiMode: process.env.GEMINI_API_KEY ? 'gemini' : 'demo',
    executionMode: 'process-based',
    timestamp: new Date().toISOString()
  })
})

// 404 handler
app.use((req, res) => res.status(404).json({ error: 'Route not found' }))

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ error: 'Internal server error', message: err.message })
})

// ─── Queue Worker ─────────────────────────────────────────────────────────────
executionQueue.process(async (job) => {
  const { code, language } = job.data
  job.updateProgress(10)
  const result = await executeCode({ code, language })
  job.updateProgress(100)
  return result
})

// ─── Socket.IO ────────────────────────────────────────────────────────────────
setupCollaboration(io)

// ─── Startup ─────────────────────────────────────────────────────────────────
async function start() {
  await initDB()
  await initExecutionService()

  httpServer.listen(PORT, () => {
    console.log(`
╔══════════════════════════════════════════════════╗
║          CodeForge AI — Backend Server           ║
╠══════════════════════════════════════════════════╣
║  🚀  Server:    http://localhost:${PORT}            ║
║  🤖  AI Mode:   ${process.env.GEMINI_API_KEY ? 'Gemini API (Real)      ' : 'Demo Mode (Mock)       '} ║
║  ⚡  Execution: Process-based (Docker-ready)    ║
║  🔌  WebSocket: Socket.IO active                ║
║  💾  Database:  LowDB (embedded)                ║
╠══════════════════════════════════════════════════╣
║  API Endpoints:                                  ║
║    POST /api/auth/register                       ║
║    POST /api/auth/login                          ║
║    POST /api/code/run                            ║
║    GET  /api/problems                            ║
║    POST /api/ai/review                           ║
║    GET  /api/analytics/me                        ║
╚══════════════════════════════════════════════════╝
    `)
  })
}

start().catch(console.error)
