import { v4 as uuidv4 } from 'uuid'

const rooms = new Map() // roomId -> { participants, code, language, messages }

export function setupCollaboration(io) {
  io.on('connection', (socket) => {
    console.log(`🔌 Client connected: ${socket.id}`)

    // Join a collaboration room
    socket.on('room:join', ({ roomId, username, avatar }) => {
      if (!roomId) {
        roomId = uuidv4().slice(0, 8).toUpperCase()
      }

      socket.join(roomId)
      socket.roomId = roomId
      socket.username = username || 'Anonymous'
      socket.avatar = avatar || '??'

      if (!rooms.has(roomId)) {
        rooms.set(roomId, {
          id: roomId,
          participants: [],
          code: '// Welcome to CodeForge AI Collaboration!\n// Start coding together in real time\n\nfunction solution() {\n  // Your collaborative code here\n}\n',
          language: 'javascript',
          messages: [],
          createdAt: new Date().toISOString()
        })
      }

      const room = rooms.get(roomId)
      const participant = {
        id: socket.id,
        username: socket.username,
        avatar: socket.avatar,
        joinedAt: new Date().toISOString(),
        cursor: null,
        color: getParticipantColor(room.participants.length)
      }

      room.participants.push(participant)

      // Send current state to new participant
      socket.emit('room:joined', {
        roomId,
        code: room.code,
        language: room.language,
        participants: room.participants,
        messages: room.messages.slice(-50)
      })

      // Notify others
      socket.to(roomId).emit('room:participant_joined', participant)
      io.to(roomId).emit('room:participants', room.participants)

      console.log(`👥 ${socket.username} joined room ${roomId}`)
    })

    // Code change (collaborative editing)
    socket.on('code:change', ({ code, language }) => {
      const roomId = socket.roomId
      if (!roomId || !rooms.has(roomId)) return

      const room = rooms.get(roomId)
      room.code = code
      if (language) room.language = language

      // Broadcast to all in room except sender
      socket.to(roomId).emit('code:change', {
        code,
        language,
        changedBy: socket.username
      })
    })

    // Cursor position update
    socket.on('cursor:move', ({ line, column }) => {
      const roomId = socket.roomId
      if (!roomId) return

      const room = rooms.get(roomId)
      if (!room) return

      const participant = room.participants.find(p => p.id === socket.id)
      if (participant) participant.cursor = { line, column }

      socket.to(roomId).emit('cursor:move', {
        userId: socket.id,
        username: socket.username,
        line, column
      })
    })

    // Chat message in room
    socket.on('chat:message', ({ message }) => {
      const roomId = socket.roomId
      if (!roomId || !rooms.has(roomId)) return

      const room = rooms.get(roomId)
      const msg = {
        id: uuidv4(),
        userId: socket.id,
        username: socket.username,
        avatar: socket.avatar,
        message,
        timestamp: new Date().toISOString()
      }

      room.messages.push(msg)
      if (room.messages.length > 200) room.messages = room.messages.slice(-200)

      io.to(roomId).emit('chat:message', msg)
    })

    // Language change
    socket.on('language:change', ({ language }) => {
      const roomId = socket.roomId
      if (!roomId || !rooms.has(roomId)) return

      rooms.get(roomId).language = language
      socket.to(roomId).emit('language:change', { language, changedBy: socket.username })
    })

    // Execution result broadcast
    socket.on('execution:result', (result) => {
      const roomId = socket.roomId
      if (!roomId) return
      socket.to(roomId).emit('execution:result', { ...result, executedBy: socket.username })
    })

    // Disconnect
    socket.on('disconnect', () => {
      const roomId = socket.roomId
      if (roomId && rooms.has(roomId)) {
        const room = rooms.get(roomId)
        room.participants = room.participants.filter(p => p.id !== socket.id)

        socket.to(roomId).emit('room:participant_left', {
          id: socket.id, username: socket.username
        })
        io.to(roomId).emit('room:participants', room.participants)

        // Clean up empty rooms after 5 minutes
        if (room.participants.length === 0) {
          setTimeout(() => {
            if (rooms.has(roomId) && rooms.get(roomId).participants.length === 0) {
              rooms.delete(roomId)
            }
          }, 5 * 60 * 1000)
        }
      }
      console.log(`🔌 Client disconnected: ${socket.id}`)
    })

    // Heartbeat
    socket.on('ping', () => socket.emit('pong'))
  })
}

function getParticipantColor(index) {
  const colors = ['#7c3aed', '#db2777', '#0891b2', '#059669', '#d97706', '#dc2626']
  return colors[index % colors.length]
}

export function getRoomInfo(roomId) {
  return rooms.get(roomId) || null
}
