import express from 'express'
import { v4 as uuidv4 } from 'uuid'
import { authMiddleware } from '../middleware/auth.js'
import { executionQueue } from '../services/queueService.js'
import { executeCode } from '../services/executionService.js'
import { submissionsDb } from '../config/db.js'

const router = express.Router()

// POST /api/code/execute — execute code, queue it, return job ID
router.post('/execute', authMiddleware, async (req, res) => {
  try {
    const { code, language = 'javascript', problemId } = req.body
    if (!code) return res.status(400).json({ error: 'Code is required' })

    const validLanguages = ['javascript', 'python', 'cpp', 'java', 'go']
    if (!validLanguages.includes(language)) {
      return res.status(400).json({ error: `Unsupported language. Use: ${validLanguages.join(', ')}` })
    }

    const job = await executionQueue.add({ code, language, problemId, userId: req.user.id })
    res.json({ jobId: job.id, status: 'queued', message: 'Code queued for execution' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/code/status/:jobId — poll execution result
router.get('/status/:jobId', authMiddleware, async (req, res) => {
  try {
    const job = await executionQueue.getJob(req.params.jobId)
    if (!job) return res.status(404).json({ error: 'Job not found' })

    if (job.status === 'completed') {
      return res.json({ status: 'completed', result: job.result })
    }
    if (job.status === 'failed') {
      return res.json({ status: 'failed', error: job.error })
    }

    res.json({ status: job.status, progress: job.progress })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/code/run — synchronous execution (for quick run button)
router.post('/run', authMiddleware, async (req, res) => {
  try {
    const { code, language = 'javascript' } = req.body
    if (!code) return res.status(400).json({ error: 'Code is required' })

    const result = await executeCode({ code, language })

    // Log submission
    const submission = {
      id: uuidv4(),
      userId: req.user.id,
      code, language,
      type: 'run',
      result,
      createdAt: new Date().toISOString()
    }
    submissionsDb.data.submissions.push(submission)
    try { submissionsDb.write() } catch(e) {}

    res.json(result)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/code/submissions — user's submission history
router.get('/submissions', authMiddleware, async (req, res) => {
  try {
    const userSubmissions = submissionsDb.data.submissions
      .filter(s => s.userId === req.user.id)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 50)
    res.json(userSubmissions)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/code/queue/stats
router.get('/queue/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await executionQueue.getStats()
    res.json(stats)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
