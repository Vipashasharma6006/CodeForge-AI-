import express from 'express'
import { authMiddleware } from '../middleware/auth.js'
import { reviewCode, debugCode, optimizeCode, explainCode, chatWithAI } from '../services/aiService.js'

const router = express.Router()

// POST /api/ai/review
router.post('/review', authMiddleware, async (req, res) => {
  try {
    const { code, language = 'javascript' } = req.body
    if (!code) return res.status(400).json({ error: 'Code is required' })
    const result = await reviewCode({ code, language })
    res.json({ result, mode: process.env.GEMINI_API_KEY ? 'gemini' : 'demo' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/ai/debug
router.post('/debug', authMiddleware, async (req, res) => {
  try {
    const { code, language = 'javascript', error } = req.body
    if (!code) return res.status(400).json({ error: 'Code is required' })
    const result = await debugCode({ code, language, error })
    res.json({ result, mode: process.env.GEMINI_API_KEY ? 'gemini' : 'demo' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/ai/optimize
router.post('/optimize', authMiddleware, async (req, res) => {
  try {
    const { code, language = 'javascript' } = req.body
    if (!code) return res.status(400).json({ error: 'Code is required' })
    const result = await optimizeCode({ code, language })
    res.json({ result, mode: process.env.GEMINI_API_KEY ? 'gemini' : 'demo' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/ai/explain
router.post('/explain', authMiddleware, async (req, res) => {
  try {
    const { code, language = 'javascript' } = req.body
    if (!code) return res.status(400).json({ error: 'Code is required' })
    const result = await explainCode({ code, language })
    res.json({ result, mode: process.env.GEMINI_API_KEY ? 'gemini' : 'demo' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/ai/chat
router.post('/chat', authMiddleware, async (req, res) => {
  try {
    const { message, code, language, history } = req.body
    if (!message) return res.status(400).json({ error: 'Message is required' })
    const result = await chatWithAI({ message, code, language, history })
    res.json({ result, mode: process.env.GEMINI_API_KEY ? 'gemini' : 'demo' })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
