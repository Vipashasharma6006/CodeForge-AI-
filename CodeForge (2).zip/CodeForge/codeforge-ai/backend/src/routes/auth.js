import express from 'express'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { v4 as uuidv4 } from 'uuid'
import { usersDb } from '../config/db.js'

const router = express.Router()

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'All fields required' })
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' })
    }

    const existing = usersDb.data.users.find(
      u => u.email === email || u.username === username
    )
    if (existing) {
      return res.status(409).json({ error: 'Username or email already taken' })
    }

    const passwordHash = await bcrypt.hash(password, 10)
    const user = {
      id: uuidv4(),
      username,
      email,
      passwordHash,
      avatar: username.slice(0, 2).toUpperCase(),
      role: 'user',
      createdAt: new Date().toISOString(),
      stats: {
        solved: 0, attempted: 0, streak: 0, rank: 9999,
        submissions: 0, languages: {}
      }
    }

    usersDb.data.users.push(user)
    await usersDb.write()

    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    )

    const { passwordHash: _, ...safeUser } = user
    res.status(201).json({ token, user: safeUser })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' })
    }

    const user = usersDb.data.users.find(u => u.email === email)
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' })
    }

    const valid = await bcrypt.compare(password, user.passwordHash)
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' })
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    )

    const { passwordHash: _, ...safeUser } = user
    res.json({ token, user: safeUser })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/auth/me
router.get('/me', async (req, res) => {
  try {
    const authHeader = req.headers.authorization
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token' })
    }
    const token = authHeader.split(' ')[1]
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    const user = usersDb.data.users.find(u => u.id === decoded.id)
    if (!user) return res.status(404).json({ error: 'User not found' })
    const { passwordHash: _, ...safeUser } = user
    res.json(safeUser)
  } catch {
    res.status(401).json({ error: 'Invalid token' })
  }
})

export default router
