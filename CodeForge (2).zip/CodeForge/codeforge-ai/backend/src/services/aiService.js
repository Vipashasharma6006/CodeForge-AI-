/**
 * AI Service — Powered by Google Gemini when API key is present,
 * falls back to rich realistic mock responses for demonstration.
 *
 * To enable real AI: add GEMINI_API_KEY to backend/.env
 * Get a free key at: https://aistudio.google.com/app/apikey
 */

const GEMINI_API_KEY = process.env.GEMINI_API_KEY

// ─── Mock response templates ─────────────────────────────────────────────────

const mockReviews = {
  review: (code, language) => `## 🔍 AI Code Review

### Overall Assessment
**Score: 7.5/10** — Good structure with room for improvement.

### ✅ Strengths
- Clean variable naming and readable logic
- Handles the base case correctly
- \`${language}\` idioms used appropriately

### ⚠️ Issues Found

**1. Time Complexity — O(n²) detected**
\`\`\`${language}
// Current approach: nested loops
${code.split('\n').slice(0, 3).join('\n')}
\`\`\`
Consider using a **HashMap** to reduce to O(n).

**2. Edge Case Missing**
- Empty array/string input is not handled
- Could throw \`TypeError\` on null input

**3. No Input Validation**
Add guard clause at the top of your function.

### 💡 Optimization Suggestion
\`\`\`javascript
// Use a Map for O(1) lookups instead of O(n) search
const map = new Map();
for (let i = 0; i < nums.length; i++) {
  const complement = target - nums[i];
  if (map.has(complement)) return [map.get(complement), i];
  map.set(nums[i], i);
}
\`\`\`

### 📋 Summary
| Metric | Value |
|--------|-------|
| Time Complexity | O(n²) → can be O(n) |
| Space Complexity | O(1) → O(n) with HashMap |
| Readability | ⭐⭐⭐⭐ |
| Error Handling | ⭐⭐ |

*Add your Gemini API key in \`.env\` for personalized AI reviews.*`,

  debug: (code) => `## 🐛 Debug Analysis

### Error Detected
Based on your code, I found the following potential issues:

**Runtime Error: Possible \`undefined\` access**
\`\`\`
Line ~${Math.floor(code.split('\n').length / 2)}: Accessing property of potentially undefined value
\`\`\`

### Root Cause
The variable is not initialized before use in the loop body. When \`nums\` is empty, the loop body attempts to access \`nums[0]\` which is \`undefined\`.

### Fix
\`\`\`javascript
// Add null check at entry point
if (!nums || nums.length === 0) return [];

// Initialize accumulator before loop
let result = null;
for (let i = 0; i < nums.length; i++) {
  // safe to access nums[i] now
}
\`\`\`

### Why This Happens
JavaScript doesn't throw on undefined property access until you try to call a method on it. Always validate inputs at function entry.

### ✅ After Fix
Your code should correctly handle:
- Empty arrays ✓
- Single-element arrays ✓  
- Negative numbers ✓

*For real-time AI debugging, add your Gemini API key to \`.env\`*`,

  optimize: (code) => `## ⚡ Optimization Report

### Performance Analysis

**Current Complexity**
| | Before | After Optimization |
|---|---|---|
| Time | O(n²) | **O(n)** |
| Space | O(1) | O(n) |
| Speed | Baseline | **~15× faster** |

### Optimized Implementation
\`\`\`javascript
function optimizedSolution(nums, target) {
  // Single-pass HashMap approach
  const seen = new Map();
  
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    
    if (seen.has(complement)) {
      return [seen.get(complement), i];
    }
    
    seen.set(nums[i], i);
  }
  
  return []; // No solution found
}
\`\`\`

### Why This Is Faster
1. **Single pass** — we only iterate through the array once
2. **O(1) lookup** — HashMap.has() is constant time
3. **Early return** — stops as soon as answer is found

### Benchmark (estimated)
- n=1000: 0.1ms → 0.007ms
- n=10000: 10ms → 0.07ms
- n=100000: 1000ms → 0.7ms

### Additional Recommendations
- Consider memoization if called repeatedly with same inputs
- Use TypedArray (Int32Array) if values are integers only — 2× faster

*Add Gemini API key for production-grade optimization analysis.*`,

  explain: (code) => `## 📖 Code Explanation

### What This Code Does
This function implements a **search algorithm** that finds elements satisfying a given condition within a collection.

### Step-by-Step Breakdown

**Step 1: Initialization**
\`\`\`javascript
// Sets up the data structure and initial state
// Time: O(1), Space: O(1)
\`\`\`

**Step 2: Iteration / Traversal**
The code traverses the input using a loop construct:
- Processes each element sequentially
- Applies the core logic condition
- Accumulates or returns results

**Step 3: Result Construction**
The final step builds the output according to the problem requirements.

### Key Concepts Used
| Concept | How It's Used |
|---------|---------------|
| **Iteration** | Linear traversal of input |
| **Conditionals** | Branch on matching criteria |
| **Return value** | Indices/values satisfying condition |

### Complexity Analysis
- **Time**: O(n) where n = input size
- **Space**: O(1) auxiliary space

### Related Patterns
- **Two-pointer technique** — for sorted arrays
- **Sliding window** — for subarray problems
- **Hash table** — for O(1) lookup

*Add your Gemini API key for context-aware explanations tailored to your exact code.*`
}

// ─── Real Gemini API Call ────────────────────────────────────────────────────

async function callGemini(prompt) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
    })
  })
  if (!response.ok) {
    const err = await response.text()
    throw new Error(`Gemini API error: ${response.status} — ${err}`)
  }
  const data = await response.json()
  return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response generated.'
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function reviewCode({ code, language }) {
  if (GEMINI_API_KEY) {
    const prompt = `You are an expert ${language} code reviewer. Review the following code thoroughly, covering: time/space complexity, bugs, code quality, edge cases, and optimization opportunities. Format your response in Markdown with clear sections.\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\``
    return callGemini(prompt)
  }
  return mockReviews.review(code, language)
}

export async function debugCode({ code, language, error }) {
  if (GEMINI_API_KEY) {
    const prompt = `You are an expert debugger. Analyze this ${language} code${error ? ` that produces error: "${error}"` : ''}. Identify the bug, explain the root cause, and provide the corrected code. Format in Markdown.\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\``
    return callGemini(prompt)
  }
  return mockReviews.debug(code)
}

export async function optimizeCode({ code, language }) {
  if (GEMINI_API_KEY) {
    const prompt = `You are a performance optimization expert. Analyze this ${language} code and provide: current complexity, optimized version, benchmark comparison, and explanation. Format in Markdown with before/after code blocks.\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\``
    return callGemini(prompt)
  }
  return mockReviews.optimize(code)
}

export async function explainCode({ code, language }) {
  if (GEMINI_API_KEY) {
    const prompt = `Explain this ${language} code in detail: what it does, how it works step by step, what algorithms/patterns it uses, and its time/space complexity. Format clearly in Markdown for a learning audience.\n\nCode:\n\`\`\`${language}\n${code}\n\`\`\``
    return callGemini(prompt)
  }
  return mockReviews.explain(code)
}

export async function chatWithAI({ message, code, language, history }) {
  if (GEMINI_API_KEY) {
    const systemContext = code
      ? `Context: User is working on ${language} code:\n\`\`\`${language}\n${code}\n\`\`\`\n\n`
      : ''
    const prompt = `${systemContext}You are CodeForge AI, an expert coding assistant. Answer this programming question clearly and concisely:\n\n${message}`
    return callGemini(prompt)
  }

  // Rich mock chat responses
  const lower = message.toLowerCase()
  if (lower.includes('time complexity') || lower.includes('big o')) {
    return `## Time Complexity Analysis\n\nFor most sorting algorithms:\n- **Bubble Sort**: O(n²)\n- **Merge Sort**: O(n log n) ✅\n- **Quick Sort**: O(n log n) average\n\nFor your current code, I'd estimate **O(n)** based on the single-loop structure.\n\n*Add a Gemini API key for code-specific analysis!*`
  }
  if (lower.includes('fix') || lower.includes('error') || lower.includes('bug')) {
    return `## Debugging Help\n\nCommon issues to check:\n1. **Off-by-one errors** in loop bounds\n2. **Null/undefined checks** before property access\n3. **Return statement** inside vs outside loop\n\nShare the error message for specific help!\n\n*Add Gemini API key for instant AI debugging.*`
  }
  if (lower.includes('hello') || lower.includes('hi')) {
    return `👋 **Hello! I'm CodeForge AI.**\n\nI can help you with:\n- 🔍 **Code reviews** — quality, bugs, best practices\n- 🐛 **Debugging** — find and fix errors\n- ⚡ **Optimization** — improve performance\n- 📖 **Explanations** — understand complex code\n\nWhat would you like help with today?`
  }
  return `## AI Response\n\nThat's a great question about **${message.slice(0, 30)}...**\n\nHere are some key considerations:\n\n1. **Algorithm choice** matters most for performance\n2. **Data structures** drive the solution elegance\n3. **Edge cases** should always be tested first\n\nWould you like me to:\n- Review your current code?\n- Suggest an optimized approach?\n- Explain a specific concept?\n\n*For real AI responses, add your Gemini API key to \`.env\`*`
}
