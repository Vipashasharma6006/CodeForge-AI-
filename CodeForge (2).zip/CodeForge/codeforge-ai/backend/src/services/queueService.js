import { EventEmitter } from 'events'
import { v4 as uuidv4 } from 'uuid'

class InMemoryQueue extends EventEmitter {
  constructor(name) {
    super()
    this.name = name
    this.jobs = new Map()
    this.processors = []
    this.concurrency = 3
    this.running = 0
  }

  async add(data, opts = {}) {
    const job = {
      id: uuidv4(),
      data,
      opts,
      status: 'waiting',
      progress: 0,
      result: null,
      error: null,
      createdAt: Date.now(),
      processedAt: null,
      finishedAt: null,
    }
    this.jobs.set(job.id, job)
    this.emit('added', job)
    setImmediate(() => this._processNext())
    return job
  }

  async getJob(id) {
    return this.jobs.get(id) || null
  }

  process(processorFn) {
    this.processors.push(processorFn)
    return this
  }

  _processNext() {
    if (this.running >= this.concurrency) return
    const waiting = [...this.jobs.values()].find(j => j.status === 'waiting')
    if (!waiting) return

    waiting.status = 'active'
    waiting.processedAt = Date.now()
    this.running++

    const processor = this.processors[0]
    if (!processor) {
      waiting.status = 'failed'
      waiting.error = 'No processor registered'
      this.running--
      return
    }

    const jobProxy = {
      ...waiting,
      updateProgress: (pct) => { waiting.progress = pct }
    }

    Promise.resolve(processor(jobProxy))
      .then(result => {
        waiting.status = 'completed'
        waiting.result = result
        waiting.finishedAt = Date.now()
        this.emit('completed', waiting, result)
      })
      .catch(err => {
        waiting.status = 'failed'
        waiting.error = err.message || String(err)
        waiting.finishedAt = Date.now()
        this.emit('failed', waiting, err)
      })
      .finally(() => {
        this.running--
        setImmediate(() => this._processNext())
      })
  }

  async getStats() {
    const jobs = [...this.jobs.values()]
    return {
      waiting: jobs.filter(j => j.status === 'waiting').length,
      active: jobs.filter(j => j.status === 'active').length,
      completed: jobs.filter(j => j.status === 'completed').length,
      failed: jobs.filter(j => j.status === 'failed').length,
    }
  }
}

// Singleton queues
export const executionQueue = new InMemoryQueue('code-execution')
export const aiQueue = new InMemoryQueue('ai-processing')

console.log('✅ In-memory job queues initialized (Redis-ready by design)')
