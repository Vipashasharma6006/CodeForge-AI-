# Senior Engineering Review — Change Log

This document is the deliverable requested in the prompt: every change made,
why it was necessary, what's left, and what should be rewritten later.
Nothing described in section 1 ("Bugs") was speculative — each was
reproduced and fixed, then re-tested against a running instance of the
server (see the "Verification" note at the end).

## 0. Security note — please rotate your Gemini key

`backend/.env` in the uploaded project contained a live-looking
`GEMINI_API_KEY`. It has been **removed** from the delivered `.env` (left
blank) and is **not** included anywhere else in this delivery. Please:
1. Revoke/rotate it at https://aistudio.google.com/app/apikey
2. Paste the new key into your local `backend/.env` only (never commit it)

---

## 1. Gemini API integration

**Before:** hand-rolled `fetch()` calls to the REST endpoint, hardcoded to
`gemini-1.5-flash`, with a single generic `catch` that surfaced no useful
information about *why* a call failed.

**After** (`backend/src/services/ai/providers/gemini.js`):
- Uses the official **`@google/genai`** SDK (the successor to the deprecated
  `@google/generative-ai` package).
- Model is configurable via `GEMINI_MODEL`, defaulting to `gemini-2.5-flash`
  as requested.
- API key is read exclusively from `process.env.GEMINI_API_KEY` via the
  validated env config (`src/config/env.js`) — never hardcoded, never logged.
- Every failure mode is caught and mapped to a specific, client-safe error:
  missing key (401), invalid/expired key (401/403), rate limit (429), model
  unavailable (404), network failure (503), provider outage (503), empty
  response (502). See the table in `README.md` §6.
- If no key is configured, the app **does not crash or 500** — it serves
  clearly-labeled demo/mock responses (moved out to
  `src/services/ai/mockResponses.js`, previously mixed into the same file as
  the API-calling logic).

**Why:** the old implementation would either crash the request with an
opaque error or (in some failure paths) silently return nothing useful to
the frontend. A code-review platform's core feature failing without
explanation is a bad experience; now every failure tells the user (and your
logs) exactly what went wrong.

---

## 2. Environment variables

**Added** `backend/.env.example` with `PORT`, `JWT_SECRET`, `GEMINI_API_KEY`,
`GEMINI_MODEL` (plus a few extras: `NODE_ENV`, `JWT_EXPIRES_IN`,
`AI_PROVIDER`, `CORS_ORIGIN` — all optional with sane defaults, documented in
the README).

**Added** `backend/src/config/env.js`, called once at the very top of
`server.js`. It:
- Throws (and exits with a readable message) if `JWT_SECRET` is missing —
  previously this would only surface the first time someone tried to log in,
  as a raw `jwt.sign` crash.
- Warns (doesn't fail) if `GEMINI_API_KEY` is absent, since demo mode is a
  valid, supported configuration.
- Returns one typed config object (`env`) that's attached to
  `app.locals.env`, so no route ever reads `process.env` directly — this is
  also what makes the AI provider swap in item 3 possible without prop-drilling.

**Why:** "fail fast at startup with a clear message" is far better than
"fail on the first real request with a stack trace."

---

## 3. AI service refactor

Split the old single-file `aiService.js` into:

```
src/services/ai/
├── prompts.js              # pure prompt-building functions, no I/O
├── mockResponses.js         # demo-mode content, unchanged from before
├── aiService.js              # orchestrates prompts + provider calls
└── providers/
    ├── gemini.js              # real implementation
    ├── openai.js, claude.js, groq.js   # stubs — see README §7
    └── index.js                # registry: getProvider(name)
```

**Why this shape:** prompt text and API-calling logic were previously
tangled together, and there was no seam for a second provider. Now:
- Every provider implements one function:
  `generate({ prompt, temperature, maxTokens, apiKey, model }) -> string`.
- Switching providers is `AI_PROVIDER=openai` in `.env` plus implementing one
  file — no route or prompt code changes.
- Prompt construction is now testable in isolation (pure functions, no
  network calls).

---

## 4. Error handling

**Added:**
- `src/utils/AppError.js` — `ValidationError` (400), `AuthError` (401),
  `NotFoundError` (404), `ConflictError` (409), `AIServiceError` (varies).
- `src/utils/asyncHandler.js` — wraps every async route handler so a
  rejected promise is forwarded to Express's error middleware instead of
  either crashing the process or hanging the request. This directly fixes
  the **unhandled promise rejection** risk: several original routes had
  async handlers with no try/catch at all, so a thrown error inside them had
  nowhere to go.
- A single centralized error-handling middleware in `server.js` that maps
  `AppError` subclasses to their status code + a safe JSON body, and logs
  (but never returns to the client) the full stack trace for anything
  unexpected.
- `process.on('unhandledRejection', ...)` and `process.on('uncaughtException', ...)`
  as a last-resort safety net, with the latter exiting the process — letting
  it limp along in an unknown state is worse than a clean restart (which
  your process manager / host should already be configured to do).

**Fixed inconsistent responses:** every route now returns errors in the same
shape: `{ error, code, details? }`, instead of a mix of `{ error }`,
plain strings, and the occasional route that let an exception's raw message
leak to the client.

---

## 5. Security

- **Input validation:** every route that accepts a body now runs it through
  `express-validator` chains (`src/middleware/validators.js`) — type checks,
  length caps (code: 20,000 chars, chat messages: 4,000 chars), an
  allow-list of supported languages, email format, username character
  allow-list, password length. Previously routes only checked `if (!code)`.
- **Sanitization:** `prompts.js` strips null bytes and other control
  characters from user code/messages before they're sent to the model, and
  hard-caps length (also enforced at the validation layer, so oversized
  payloads are rejected before reaching the AI call at all).
- **Prompt-injection mitigation:** every prompt fences user code as
  explicitly-labeled *data* and instructs the model to ignore any embedded
  commands. This is a real, standard mitigation — not a complete defense
  (see "Known limitations" in the README).
- **Secrets never logged:** `src/utils/logger.js` redacts any key named
  `apikey`, `authorization`, `jwt_secret`, `password`, `token`, etc. before
  writing to stdout, and also strips bearer-token-shaped strings from any
  logged text. Combined with the AI error normalization, the raw API key
  never appears in a log line or an HTTP response.
- **Secrets never sent to the frontend:** `GET /api/ai/status` and
  `GET /api/health` report only whether AI is configured (boolean) and which
  provider/model — never the key itself.
- **CORS:** now configurable via `CORS_ORIGIN` (comma-separated list),
  defaulting to `*` for local/demo use. The README calls out setting this to
  your real frontend origin in production.
- **JWT:** unchanged algorithm/flow (still `jsonwebtoken` + `bcryptjs`), but
  `env.js` now refuses to boot in production with the sample secret from
  `.env.example`, and warns about it in development.
- **Rate limiting:** kept the existing general limiter, and added two
  narrower ones: a stricter limiter on `/api/auth/*` (brute-force
  protection) and one on `/api/ai/*` (protects your Gemini quota/bill from
  abuse) — both independent of the general API limiter.

---

## 6. Code quality

- Removed the unused `lowdb` dependency (the app has used a hand-rolled JSON
  store, `src/config/db.js`, for a while — `lowdb` was never actually
  imported anywhere).
- Removed a duplicate `import path from 'path'` in `db.js`.
- Consistent naming: `AppError` subclasses, one `asyncHandler` pattern
  everywhere, one validation pattern everywhere, one logger everywhere.
- Reusable helpers: `asyncHandler`, `validate`, the reusable validator chains
  in `validators.js`, and the provider registry all exist specifically to
  avoid the copy-pasted try/catch and manual `if (!field)` blocks that were
  spread across the original route files.
- Added `.gitignore` (there wasn't one — `node_modules` was inside the
  uploaded zip).

---

## 7. Performance

- AI and auth now have **dedicated rate limits** tuned lower than the
  general API limit, since those are the two most expensive/abusable
  operations (LLM cost, brute-force risk) — this is a cost/availability
  safeguard as much as a performance one.
- Prompt length caps (20k/4k chars) bound token usage per request, so one
  oversized paste can't balloon your Gemini bill or request latency.
- No functional changes were made to `executionService.js` or
  `queueService.js` — their approach (child-process execution, in-memory
  queue) was already reasonable for the app's current scale; see "Known
  limitations" in the README for where this should evolve if traffic grows.

## 8. Frontend

- Centralized all API calls behind one `src/api/client.js` axios instance
  instead of six separate `import axios from 'axios'` + manual
  `axios.defaults.headers` mutations. Behavior is identical locally; the
  real payoff is that the base URL is now one environment variable
  (`VITE_API_BASE_URL`) instead of being implicitly "whatever the current
  page origin is" — which is what made a split Vercel/Railway deployment
  impossible before.
- Same fix for the Socket.IO connection in `CollabPage.jsx`
  (`VITE_SOCKET_URL`).
- Reviewed `IDEPage.jsx`, `CollabPage.jsx`, `DashboardPage.jsx`,
  `ProblemsPage.jsx`, `ProblemDetailPage.jsx`: loading states, error toasts,
  and responsive layout were already handled reasonably well in the original
  code, so no rewrites were made there — see the README's "Known
  limitations" for the one relevant note (dark-mode-only, by design).

## 9. Backend

Covered above (routes, middleware, auth, validation, AI routes,
architecture) — see sections 3–6.

## 10. Bugs found and fixed

- **Missing env validation** → startup crash risk on first login
  (`JWT_SECRET` undefined). Fixed by §2.
- **No error boundary for async routes** → some routes could leave a
  request hanging or crash the process on a rejected promise. Fixed by
  `asyncHandler` + centralized error middleware.
- **Dead dependency** (`lowdb`) and duplicate import in `db.js`.
- **API key exposure risk**: the original `.env` had a real key committed to
  the delivered zip; the AI status endpoint could theoretically have grown
  to leak more than a boolean over time without a documented contract — now
  explicit in `getAIStatus()`.
- **Deployment-blocking assumption**: the frontend assumed same-origin
  `/api/...` in production, which silently breaks the moment frontend and
  backend are on different domains (exactly the Vercel + separate-backend
  scenario you asked for). Fixed by §8.

## 11. Remaining issues / recommended future rewrites

(Also listed in the README's "Known limitations" section, kept here too
since the prompt asked for it explicitly in this document.)

1. **JSON-file database** — no concurrency safety, incompatible with
   ephemeral/serverless filesystems. Replace with Postgres/MongoDB before
   scaling past one always-on instance.
2. **In-memory job queue & collaboration state** — resets on restart, can't
   be horizontally scaled. Move to Redis-backed BullMQ + Socket.IO's Redis
   adapter when you need more than one backend instance.
3. **`vm`-based JS sandbox** — adequate isolation for a demo, not a hard
   security boundary for arbitrary untrusted code at scale. For a public,
   high-traffic deployment, run submissions in locked-down containers
   (gVisor/Firecracker) instead.
4. **No automated tests** — recommend Vitest (frontend) and
   Jest/Vitest + supertest (backend routes) as the next investment.
5. **Prompt-injection mitigation is best-effort**, as it must be with any
   purely textual defense — worth revisiting if the AI features ever act on
   tool calls or write access rather than just returning text.

---

## Verification performed

Before delivery, the refactored backend was booted locally and exercised
end-to-end (register → login → protected route without token → run code →
AI review in demo mode → 404 handling → validation on bad input), and the
Gemini provider's error-normalization logic was unit-tested against
simulated 401/404/429/503/network-failure responses to confirm each maps to
the correct status code and message described in §1. All passed. The
frontend changes were verified by static review (no bundler available in
this sandbox to run a full Vite build) — please run `npm run dev:frontend`
as your first check after installing.
