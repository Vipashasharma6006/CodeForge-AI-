import React, { useState, useRef, useCallback } from 'react'
import Editor, { useMonaco } from '@monaco-editor/react'
import { api as axios } from '../api/client.js'
import toast from 'react-hot-toast'
import ReactMarkdown from 'react-markdown'
import './IDEPage.css'

const LANGUAGES = [
  { value: 'javascript', label: 'JavaScript' },
  { value: 'python', label: 'Python' },
  { value: 'cpp', label: 'C++' },
  { value: 'java', label: 'Java' },
  { value: 'c', label: 'C' },
  { value: 'go', label: 'Go' },
]

const STARTERS = {
  javascript: `// CodeForge AI — JavaScript Playground
// Press Run or Ctrl+Enter to execute

function greet(name) {
  return \`Hello, \${name}! Welcome to CodeForge AI.\`;
}

function fib(n, memo = {}) {
  if (n <= 1) return n;
  if (memo[n]) return memo[n];
  memo[n] = fib(n - 1, memo) + fib(n - 2, memo);
  return memo[n];
}

console.log(greet('World'));
console.log('Fibonacci(10):', fib(10));
console.log('First 10 fibs:', Array.from({length: 10}, (_, i) => fib(i)));`,
  python: `# CodeForge AI — Python Playground
def greet(name):
    return f"Hello, {name}! Welcome to CodeForge AI."

def fib(n, memo={}):
    if n <= 1: return n
    if n in memo: return memo[n]
    memo[n] = fib(n-1) + fib(n-2)
    return memo[n]

print(greet("World"))
print("Fibonacci(10):", fib(10))
print("First 10 fibs:", [fib(i) for i in range(10)])`,
  cpp: `// CodeForge AI — C++ Playground
#include <iostream>
#include <vector>
using namespace std;

int fib(int n) {
    if (n <= 1) return n;
    vector<int> dp(n+1);
    dp[0]=0; dp[1]=1;
    for(int i=2; i<=n; i++) dp[i]=dp[i-1]+dp[i-2];
    return dp[n];
}

int main() {
    cout << "Hello from CodeForge AI!" << endl;
    cout << "Fibonacci(10): " << fib(10) << endl;
    return 0;
}`,
  java: `// CodeForge AI — Java Playground
public class Solution {
    static int fib(int n) {
        if (n <= 1) return n;
        int[] dp = new int[n+1];
        dp[0]=0; dp[1]=1;
        for(int i=2; i<=n; i++) dp[i]=dp[i-1]+dp[i-2];
        return dp[n];
    }
    public static void main(String[] args) {
        System.out.println("Hello from CodeForge AI!");
        System.out.println("Fibonacci(10): " + fib(10));
    }
}`,
  c: `// CodeForge AI — C Playground
#include <stdio.h>
#include <stdlib.h>

int fib(int n) {
    if (n <= 1) return n;
    int *dp = (int*)malloc((n + 1) * sizeof(int));
    dp[0] = 0; dp[1] = 1;
    for(int i=2; i<=n; i++) dp[i]=dp[i-1]+dp[i-2];
    int result = dp[n];
    free(dp);
    return result;
}

int main() {
    printf("Hello from CodeForge AI!\\n");
    printf("Fibonacci(10): %d\\n", fib(10));
    return 0;
}`,
  go: `// CodeForge AI — Go Playground
package main
import "fmt"

func fib(n int) int {
    if n <= 1 { return n }
    dp := make([]int, n+1)
    dp[0], dp[1] = 0, 1
    for i := 2; i <= n; i++ { dp[i] = dp[i-1] + dp[i-2] }
    return dp[n]
}

func main() {
    fmt.Println("Hello from CodeForge AI!")
    fmt.Printf("Fibonacci(10): %d\\n", fib(10))
}`
}

const AI_TABS = ['💬 Chat', '🔍 Review', '🐛 Debug', '⚡ Optimize', '📖 Explain']
const AI_MODES = ['chat', 'review', 'debug', 'optimize', 'explain']

export default function IDEPage() {
  const [language, setLanguage] = useState('javascript')
  const [code, setCode] = useState(STARTERS.javascript)
  const [output, setOutput] = useState(null)
  const [running, setRunning] = useState(false)
  const [aiTab, setAiTab] = useState(0)
  const [aiLoading, setAiLoading] = useState(false)
  const [aiResponse, setAiResponse] = useState('')
  const [chatInput, setChatInput] = useState('')
  const [chatHistory, setChatHistory] = useState([
    { role: 'ai', content: "👋 Hi! I'm CodeForge AI. Write some code and I'll help you review, debug, or optimize it. What are you working on?" }
  ])
  const [activePanel, setActivePanel] = useState('output')
  const editorRef = useRef(null)
  const monaco = useMonaco()

  const handleLangChange = (lang) => {
    setLanguage(lang)
    setCode(STARTERS[lang])
    setOutput(null)
  }

  const runCode = useCallback(async () => {
    if (!code.trim()) return toast.error('Write some code first!')
    setRunning(true)
    setActivePanel('output')
    try {
      const res = await axios.post('/api/code/run', { code, language })
      setOutput(res.data)
    } catch (err) {
      setOutput({ stdout: '', stderr: err.response?.data?.error || 'Execution failed', exitCode: 1, runtime: 0 })
    } finally { setRunning(false) }
  }, [code, language])

  const callAI = async (mode) => {
    if (!code.trim()) return toast.error('Write some code first!')
    setAiLoading(true)
    setActivePanel('ai')
    setAiResponse('')
    const endpointMap = { review: '/api/ai/review', debug: '/api/ai/debug', optimize: '/api/ai/optimize', explain: '/api/ai/explain' }
    try {
      const res = await axios.post(endpointMap[mode], { code, language })
      setAiResponse(res.data.result)
    } catch (err) {
      setAiResponse('❌ ' + (err.response?.data?.error || 'AI service error. Make sure backend is running.'))
    } finally { setAiLoading(false) }
  }

  const sendChat = async () => {
    if (!chatInput.trim()) return
    const msg = chatInput.trim()
    setChatInput('')
    setChatHistory(h => [...h, { role: 'user', content: msg }])
    setAiLoading(true)
    setActivePanel('ai')
    try {
      const res = await axios.post('/api/ai/chat', { message: msg, code, language })
      setChatHistory(h => [...h, { role: 'ai', content: res.data.result }])
    } catch {
      setChatHistory(h => [...h, { role: 'ai', content: '❌ AI service unavailable. Add GEMINI_API_KEY to backend/.env for real responses.' }])
    } finally { setAiLoading(false) }
  }

  const handleEditorMount = (editor, monacoInstance) => {
    editorRef.current = editor
    editor.addAction({
      id: 'run-code',
      label: 'Run Code',
      keybindings: [monacoInstance.KeyMod.CtrlCmd | monacoInstance.KeyCode.Enter],
      run: () => runCode()
    })
  }

  return (
    <div className="ide-page">
      <div className="ide-toolbar">
        <div className="ide-toolbar-left">
          <span className="ide-title">💻 CodeForge IDE</span>
          <div className="lang-selector">
            {LANGUAGES.map(l => (
              <button key={l.value} className={`lang-btn ${language === l.value ? 'active' : ''}`}
                onClick={() => handleLangChange(l.value)}>{l.label}</button>
            ))}
          </div>
        </div>
        <div className="ide-toolbar-right">
          <button className="btn btn-secondary btn-sm" onClick={() => setCode(STARTERS[language])}>↺ Reset</button>
          <button className={`btn btn-primary ${running ? 'running' : ''}`} onClick={runCode} disabled={running} id="run-btn">
            {running ? <><div className="spinner" /> Running...</> : '▶ Run Code'}
          </button>
        </div>
      </div>

      <div className="ide-layout">
        <div className="editor-pane">
          <div className="editor-header">
            <span className="editor-filename">solution.{language === 'javascript' ? 'js' : language === 'python' ? 'py' : language === 'cpp' ? 'cpp' : language === 'java' ? 'java' : language === 'c' ? 'c' : 'go'}</span>
            <span className="editor-hint hide-mobile">Ctrl+Enter to run</span>
          </div>
          <div className="editor-body">
            <Editor height="100%" language={language} value={code} onChange={val => setCode(val || '')}
              onMount={handleEditorMount} theme="vs-dark"
              options={{ fontSize: 14, fontFamily: "'JetBrains Mono', 'Fira Code', monospace", fontLigatures: true, minimap: { enabled: false }, scrollBeyondLastLine: false, automaticLayout: true, padding: { top: 12, bottom: 12 }, lineNumbers: 'on', cursorBlinking: 'smooth', smoothScrolling: true, tabSize: 2, wordWrap: 'on' }} />
          </div>
        </div>

        <div className="right-pane">
          <div className="panel-tabs">
            <button className={`panel-tab ${activePanel === 'output' ? 'active' : ''}`} onClick={() => setActivePanel('output')}>
              ⚡ Output {output && <span className={`tab-dot ${output.exitCode === 0 ? 'success' : 'error'}`} />}
            </button>
            <button className={`panel-tab ${activePanel === 'ai' ? 'active' : ''}`} onClick={() => setActivePanel('ai')}>🤖 AI Assistant</button>
          </div>

          {activePanel === 'output' && (
            <div className="output-panel">
              {!output ? (
                <div className="output-empty">
                  <div className="output-empty-icon">▶</div>
                  <p>Click <strong>Run Code</strong> or press <kbd>Ctrl+Enter</kbd></p>
                </div>
              ) : (
                <div className="output-content">
                  <div className="output-meta-bar">
                    <span className={`exec-status ${output.exitCode === 0 ? 'success' : 'error'}`}>{output.exitCode === 0 ? '✅ Success' : '❌ Error'}</span>
                    <span>⏱ {output.runtime}ms</span>
                    {output.memory && <span>💾 {output.memory}</span>}
                    <span className="lang-badge">{output.language}</span>
                  </div>
                  {output.stdout && <div className="output-section"><div className="output-section-label success">▶ Output</div><pre className="output-pre success">{output.stdout}</pre></div>}
                  {output.stderr && <div className="output-section"><div className="output-section-label error">✖ Error</div><pre className="output-pre error">{output.stderr}</pre></div>}
                  {!output.stdout && !output.stderr && <div className="output-section"><pre className="output-pre">(no output)</pre></div>}
                  {output.exitCode !== 0 && <div className="quick-ai"><span>🤖 AI Help:</span><button className="btn btn-secondary btn-sm" onClick={() => { setAiTab(2); callAI('debug') }}>Debug Error</button></div>}
                </div>
              )}
            </div>
          )}

          {activePanel === 'ai' && (
            <div className="ai-panel">
              <div className="ai-subtabs">
                {AI_TABS.map((t, i) => (
                  <button key={t} className={`ai-subtab ${aiTab === i ? 'active' : ''}`}
                    onClick={() => { setAiTab(i); if (i > 0) callAI(AI_MODES[i]) }}>{t}</button>
                ))}
              </div>

              {aiTab === 0 ? (
                <div className="chat-mode">
                  <div className="chat-messages">
                    {chatHistory.map((m, i) => (
                      <div key={i} className={`chat-msg ${m.role}`}>
                        <div className="chat-avatar">{m.role === 'ai' ? '🤖' : '👤'}</div>
                        <div className="chat-bubble"><ReactMarkdown>{m.content}</ReactMarkdown></div>
                      </div>
                    ))}
                    {aiLoading && (
                      <div className="chat-msg ai">
                        <div className="chat-avatar">🤖</div>
                        <div className="chat-bubble typing"><span /><span /><span /></div>
                      </div>
                    )}
                  </div>
                  <div className="chat-input-bar">
                    <input className="input" placeholder="Ask about your code..." value={chatInput}
                      onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendChat()} disabled={aiLoading} />
                    <button className="btn btn-primary btn-sm" onClick={sendChat} disabled={aiLoading || !chatInput.trim()}>Send</button>
                  </div>
                </div>
              ) : (
                <div className="ai-result">
                  {aiLoading ? (
                    <div className="ai-loading">
                      <div className="ai-loading-bars"><span /><span /><span /><span /></div>
                      <p>AI is analyzing your code...</p>
                    </div>
                  ) : aiResponse ? (
                    <div className="ai-markdown"><ReactMarkdown>{aiResponse}</ReactMarkdown></div>
                  ) : (
                    <div className="ai-empty"><p>Select a tab above to analyze your code with AI.</p></div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
