/**
 * Centralized axios instance.
 *
 * Every page previously called the global `axios` singleton with relative
 * paths like `/api/problems`. That only works when the frontend and backend
 * are served from the same origin (or Vite's dev proxy is in front of it).
 *
 * For a split deployment — frontend on Vercel, backend on Railway/Render/etc
 * — the frontend needs to know the backend's real URL. Set VITE_API_BASE_URL
 * in the frontend's .env (see .env.example) to that URL; leave it empty for
 * local dev (Vite's proxy in vite.config.js forwards /api to localhost:5000)
 * or for same-origin production deployments.
 */
import axios from 'axios'

const baseURL = import.meta.env.VITE_API_BASE_URL || ''

export const api = axios.create({ baseURL })

const TOKEN_KEY = 'cf_token'

export function setAuthToken(token) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token)
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`
  } else {
    localStorage.removeItem(TOKEN_KEY)
    delete api.defaults.headers.common['Authorization']
  }
}

export function getStoredToken() {
  return localStorage.getItem(TOKEN_KEY)
}

// Re-apply a persisted token on page load/refresh.
const existingToken = getStoredToken()
if (existingToken) {
  api.defaults.headers.common['Authorization'] = `Bearer ${existingToken}`
}

/**
 * The Socket.IO server URL, for the same split-deployment scenario. Falls
 * back to same-origin ('/') which is what the Vite dev proxy expects.
 */
export const socketBaseURL = import.meta.env.VITE_SOCKET_URL || '/'
