# CodeForge AI

A full-stack, AI-assisted online code editor and competitive-programming platform.
React (Vite) frontend + Node.js/Express backend, with real-time collaboration
(Socket.IO), sandboxed code execution, and Gemini-powered code review/debug/
optimize/explain/chat.

> This README documents the project **after** a senior-engineer review pass —
> see [`REVIEW_NOTES.md`](./REVIEW_NOTES.md) for a full list of what changed and why.

---

## 1. Project structure

```
codeforge-ai/
├── backend/            Express API, Socket.IO, code execution, AI service
│   ├── src/
│   │   ├── config/     env validation, JSON-file "database"
│   │   ├── middleware/ auth, request validation
│   │   ├── routes/     auth, code, problems, ai, analytics
│   │   ├── services/
│   │   │   ├── ai/     prompts, providers/ (gemini + stubs), aiService
│   │   │   ├── executionService.js   sandboxed code runner
│   │   │   └── queueService.js       in-memory job queue
│   │   ├── socket/      real-time collaboration handler
│   │   └── utils/       AppError, asyncHandler, logger
│   ├── data/            JSON "database" files (users, submissions, rooms, problems)
│   ├── .env.example
│   └── server.js
└── frontend/            React + Vite SPA
    ├── src/
    │   ├── api/client.js   centralized axios instance + socket URL config
    │   ├── pages/
    │   ├── store/AuthContext.jsx
    │   └── styles/
    ├── .env.example
    └── vercel.json
```

---

## 2. Prerequisites

- Node.js 18+ (uses native `fetch`, ES modules)
- npm 9+
- Optional, for non-JS code execution: `python3`, `g++`/`gcc`, `java`/`javac`, `go`
  on the machine running the backend. If a runtime isn't installed, that
  language simply returns a friendly "runtime not found" message — JavaScript
  execution always works.

---

## 3. Installation

```bash
git clone <your-repo-url>
cd codeforge-ai
npm run install:all     # installs backend/ and frontend/ dependencies
```

---

## 4. Environment variables

### Backend — `backend/.env`

Copy the example and fill in your values:

```bash
cp backend/.env.example backend/.env
```

| Variable         | Required | Default            | Notes                                                             |
|------------------|----------|---------------------|--------------------------------------------------------------------|
| `PORT`           | no       | `5000`              | Port the API listens on                                          |
| `NODE_ENV`       | no       | `development`        | Set to `production` when deployed                                 |
| `JWT_SECRET`     | **yes**  | —                     | Long random string. Generate one: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `JWT_EXPIRES_IN` | no       | `7d`                 | Token lifetime                                                    |
| `GEMINI_API_KEY` | no       | —                     | Leave blank to run AI endpoints in **demo/mock mode**. Get a free key at https://aistudio.google.com/app/apikey |
| `GEMINI_MODEL`   | no       | `gemini-2.5-flash`   | Any current Gemini model name                                     |
| `AI_PROVIDER`    | no       | `gemini`              | Provider to use (see [Adding an AI provider](#7-adding-a-new-ai-provider)) |
| `CORS_ORIGIN`    | no       | `*`                   | Comma-separated list of allowed frontend origins in production   |

The app **validates these at startup** and refuses to boot with a clear error
message if `JWT_SECRET` is missing (see `backend/src/config/env.js`).

### Frontend — `frontend/.env`

```bash
cp frontend/.env.example frontend/.env
```

| Variable              | Required | Notes                                                                 |
|-----------------------|----------|------------------------------------------------------------------------|
| `VITE_API_BASE_URL`   | no       | Leave blank for local dev (Vite proxies `/api`). Set to your deployed backend URL for split deployments (e.g. Vercel frontend + Railway backend). |
| `VITE_SOCKET_URL`     | no       | Same idea, for the Socket.IO connection.                                |

---

## 5. Running locally

**Backend** (from repo root):
```bash
npm run dev:backend
# → http://localhost:5000
```

**Frontend** (in a second terminal):
```bash
npm run dev:frontend
# → http://localhost:3000  (proxies /api and /socket.io to :5000)
```

Demo login (seeded automatically on first run):
- email: `demo@codeforge.ai`
- password: `demo1234`

---

## 6. Gemini API setup

1. Get a free API key at **https://aistudio.google.com/app/apikey**.
2. Paste it into `backend/.env`:
   ```
   GEMINI_API_KEY=your-key-here
   GEMINI_MODEL=gemini-2.5-flash
   ```
3. Restart the backend. The startup banner and `GET /api/health` /
   `GET /api/ai/status` will show whether AI calls are live or in demo mode.

Without a key, `/api/ai/*` routes still work — they return clearly-labeled
mock responses, so the app is fully usable without any AI cost.

### How AI errors are handled

The Gemini integration (`backend/src/services/ai/providers/gemini.js`) uses the
official **`@google/genai`** SDK and normalizes every failure mode into a
client-safe JSON error instead of crashing the request:

| Situation                  | HTTP status | `code`                    |
|-----------------------------|-------------|----------------------------|
| No API key configured        | 401         | `AI_MISSING_KEY`           |
| Invalid/expired/unauthorized key | 401     | `AI_INVALID_KEY`           |
| Rate limit / quota exceeded   | 429         | `AI_RATE_LIMITED`          |
| Requested model unavailable   | 404         | `AI_MODEL_UNAVAILABLE`     |
| Network failure (DNS, refused)| 503         | `AI_NETWORK_ERROR`         |
| Gemini API down                | 503        | `AI_PROVIDER_DOWN`        |
| Empty model response           | 502        | `AI_EMPTY_RESPONSE`       |

---

## 7. Adding a new AI provider

`src/services/ai/providers/` defines one file per provider, each exporting:

```js
async function generate({ prompt, temperature, maxTokens, apiKey, model }) {
  // return a string, or throw an AIServiceError
}
```

`openai.js`, `claude.js`, and `groq.js` are already stubbed out with comments
on exactly what to install and implement. Once implemented, set
`AI_PROVIDER=openai` (etc.) in `.env` — nothing else in the app needs to change,
since `aiService.js` and the routes only ever call `getProvider(env.aiProvider)`.

---

## 8. Deploying

### Frontend → Vercel

The frontend is a static Vite build and deploys to Vercel with no changes needed:

1. Import the `frontend/` folder as a Vercel project (or set **Root Directory**
   to `frontend` if deploying the whole monorepo).
2. Build command: `npm run build` · Output directory: `dist` (already set in
   `frontend/vercel.json`, which also adds the SPA rewrite rule so client-side
   routes like `/problems/two-sum` work on refresh/deep-link).
3. Set environment variables in the Vercel dashboard:
   - `VITE_API_BASE_URL` = your deployed backend URL (e.g. `https://codeforge-api.up.railway.app`)
   - `VITE_SOCKET_URL` = same URL

### Backend → **not** Vercel (see why below), use Railway/Render/Fly.io instead

**Important:** the backend is not a good fit for Vercel's serverless functions,
for three concrete reasons in this codebase:

1. **Socket.IO** (`src/socket/collaborationHandler.js`) needs a persistent,
   long-lived WebSocket connection. Vercel serverless functions are
   short-lived and stateless per invocation — real-time collaboration would
   not work.
2. **Code execution** (`src/services/executionService.js`) spawns child
   processes (`python`, `g++`, `javac`, `go run`) for non-JS languages. Vercel's
   function environment doesn't include these compilers/runtimes and doesn't
   allow arbitrary process spawning the way a normal server does.
3. **The JSON file "database"** (`src/config/db.js`) writes to local disk.
   Vercel's filesystem is read-only outside of `/tmp`, and `/tmp` is not
   shared across invocations or persistent — user accounts and submissions
   would vanish between requests.

None of this is a knock on Vercel — it's simply built for stateless
request/response and static hosting, and this backend is intentionally a
stateful, long-running server (a fair trade for how the app works).

**Recommended:** deploy `backend/` to **Railway**, **Render**, **Fly.io**, or
any plain VM/Docker host that keeps one process running:

1. Set the service's root/start directory to `backend/`.
2. Build/start command: `npm install && npm start`.
3. Set the environment variables from the table above (`JWT_SECRET`,
   `GEMINI_API_KEY`, etc.) in that platform's dashboard — never commit `.env`.
4. Set `CORS_ORIGIN` to your Vercel frontend's URL once you have it, e.g.
   `CORS_ORIGIN=https://codeforge-ai.vercel.app`.
5. Point the frontend's `VITE_API_BASE_URL` / `VITE_SOCKET_URL` at this
   backend's URL and redeploy the frontend.

If you specifically need everything on Vercel, the realistic path is to
**split the app**: keep `auth`/`problems`/`analytics` (stateless, DB-backed)
as Vercel serverless functions with a real hosted database, and run
`code execution` + `collaboration` as a separate always-on service — that's a
non-trivial re-architecture, not a config change, so it's called out here
rather than attempted silently.

---

## 9. Known limitations / good next steps

- **JSON-file database.** Fine for a demo, but has no concurrency safety and
  won't survive a serverless/ephemeral filesystem. Swap `src/config/db.js`
  for a real database (Postgres, MongoDB, etc.) before scaling this beyond a
  single always-on instance.
- **In-memory job queue & collaboration rooms.** `queueService.js` and
  `collaborationHandler.js` keep all state in process memory, so it resets on
  restart and can't be load-balanced across multiple instances. A Redis-backed
  queue (e.g. BullMQ) and a Socket.IO Redis adapter are the natural upgrade
  path — the code is already structured (`InMemoryQueue`) to make that swap
  contained to one file.
- **JavaScript execution sandbox.** Uses Node's built-in `vm` module with a
  timeout, which is reasonable isolation for a demo but is not a hard security
  boundary. For production-grade untrusted code execution, run each
  submission in a locked-down container (gVisor/Firecracker/Docker with
  strict resource limits), not in-process.
- **Prompt-injection mitigation is best-effort.** `src/services/ai/prompts.js`
  fences user code as data and instructs the model to ignore embedded
  commands, which meaningfully reduces (but cannot fully eliminate) prompt
  injection risk — there's no purely textual defense that's airtight.
- **No automated tests.** The review focused on correctness, security, and
  architecture; adding a test suite (Vitest for the frontend, a runner like
  Jest/Vitest + supertest for the backend routes) would be the next
  investment.
- **Dark-mode-only UI.** The app currently ships one consistent dark theme
  (no light-mode toggle). That's consistent everywhere by design, not a bug —
  call it out here in case a light theme is wanted later.

---

## 10. Screenshots

_Add screenshots here once you have a running deployment, e.g.:_

| Home | IDE | Collaboration | Dashboard |
|------|-----|----------------|-----------|
| ![home](docs/screenshots/home.png) | ![ide](docs/screenshots/ide.png) | ![collab](docs/screenshots/collab.png) | ![dashboard](docs/screenshots/dashboard.png) |

---

## 11. API overview

| Method | Route                        | Auth | Description |
|--------|-------------------------------|------|--------------|
| POST   | `/api/auth/register`           | no   | Create account |
| POST   | `/api/auth/login`               | no   | Log in |
| GET    | `/api/auth/me`                   | yes  | Current user |
| POST   | `/api/code/run`                 | yes  | Run code synchronously |
| POST   | `/api/code/execute`             | yes  | Queue code for async execution |
| GET    | `/api/code/status/:jobId`        | yes  | Poll async job |
| GET    | `/api/code/submissions`         | yes  | Your submission history |
| GET    | `/api/problems`                  | opt  | List problems |
| GET    | `/api/problems/:id`               | opt  | Problem detail |
| POST   | `/api/problems/:id/submit`       | yes  | Submit a solution |
| POST   | `/api/ai/review` \| `/debug` \| `/optimize` \| `/explain` \| `/chat` | yes | AI assistant |
| GET    | `/api/ai/status`                  | no   | Whether AI is live or demo mode |
| GET    | `/api/analytics/me`               | yes  | Personal stats |
| GET    | `/api/analytics/leaderboard`     | no   | Global leaderboard |
| GET    | `/api/health`                      | no   | Health check |
