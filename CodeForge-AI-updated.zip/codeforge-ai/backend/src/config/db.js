/**
 * Simple JSON file-based database — no external dependencies
 * Drop-in replacement for LowDB with async-compatible API
 */
import fs from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { v4 as uuidv4 } from 'uuid'
import bcrypt from 'bcryptjs'

const __dirname = dirname(fileURLToPath(import.meta.url))
const dataDir = join(__dirname, '../../data')

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true })

function createStore(filename, defaultData) {
  const filepath = join(dataDir, filename)

  // Load existing or default
  let data
  try {
    data = JSON.parse(fs.readFileSync(filepath, 'utf8'))
  } catch {
    data = { ...defaultData }
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2))
  }

  const store = {
    data,
    write() { fs.writeFileSync(filepath, JSON.stringify(this.data, null, 2)) },
    async writeAsync() { fs.writeFileSync(filepath, JSON.stringify(this.data, null, 2)) }
  }

  return store
}

export let usersDb, submissionsDb, roomsDb

export async function initDB() {
  usersDb = createStore('users.json', { users: [] })
  submissionsDb = createStore('submissions.json', { submissions: [] })
  roomsDb = createStore('rooms.json', { rooms: [] })

  // Seed demo user if none exist
  if (usersDb.data.users.length === 0) {
    const hash = await bcrypt.hash('demo1234', 10)
    usersDb.data.users.push({
      id: uuidv4(),
      username: 'devhero',
      email: 'demo@codeforge.ai',
      passwordHash: hash,
      avatar: 'DH',
      role: 'user',
      createdAt: new Date().toISOString(),
      stats: {
        solved: 12, attempted: 18, streak: 5, rank: 142,
        submissions: 34, languages: { javascript: 15, python: 12, cpp: 7 }
      }
    })
    usersDb.write()
  }

  console.log('✅ Database initialized (JSON file store)')
  return { usersDb, submissionsDb, roomsDb }
}
