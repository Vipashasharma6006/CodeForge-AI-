/**
 * Startup environment validation.
 *
 * Fails fast with a clear message instead of letting the app boot into a
 * broken state (e.g. JWT signing throwing on the first login attempt
 * because JWT_SECRET was undefined). Call validateEnv() once, before the
 * server starts listening.
 */
import { logger } from '../utils/logger.js'

const DEFAULT_JWT_SECRET = 'codeforge_super_secret_jwt_key_change_in_production'

// Required for the app to function at all.
const REQUIRED_VARS = ['JWT_SECRET']

export function validateEnv() {
  const errors = []
  const warnings = []

  for (const key of REQUIRED_VARS) {
    if (!process.env[key] || process.env[key].trim() === '') {
      errors.push(`Missing required environment variable: ${key}`)
    }
  }

  if (process.env.JWT_SECRET === DEFAULT_JWT_SECRET) {
    const msg = 'JWT_SECRET is set to the sample value from .env.example — change this before deploying.'
    if (process.env.NODE_ENV === 'production') errors.push(msg)
    else warnings.push(msg)
  }

  if (!process.env.GEMINI_API_KEY) {
    warnings.push('GEMINI_API_KEY is not set — AI endpoints will run in demo/mock mode.')
  }

  if (!process.env.PORT) {
    warnings.push('PORT is not set — defaulting to 5000.')
  }

  warnings.forEach(w => logger.warn(w))

  if (errors.length > 0) {
    errors.forEach(e => logger.error(e))
    throw new Error(
      `Environment validation failed:\n  - ${errors.join('\n  - ')}\n\n` +
      `Copy backend/.env.example to backend/.env and fill in the required values.`
    )
  }

  return {
    port: Number(process.env.PORT) || 5000,
    nodeEnv: process.env.NODE_ENV || 'development',
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
    geminiApiKey: process.env.GEMINI_API_KEY || null,
    geminiModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    aiProvider: process.env.AI_PROVIDER || 'gemini',
    corsOrigin: process.env.CORS_ORIGIN || '*',
  }
}
