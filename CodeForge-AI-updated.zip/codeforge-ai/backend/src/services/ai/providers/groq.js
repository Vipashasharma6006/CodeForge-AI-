/**
 * Placeholder provider for Groq — same interface as gemini.js.
 *
 * To wire this up for real:
 *   1. npm install groq-sdk
 *   2. Add GROQ_API_KEY / GROQ_MODEL to .env and env.js
 *   3. Implement generate() using client.chat.completions.create(...)
 *   4. Register it in ./index.js
 */
import { AIServiceError } from '../../../utils/AppError.js'

export async function generate() {
  throw new AIServiceError('Groq provider is not yet configured on this server.', 501, 'AI_PROVIDER_NOT_IMPLEMENTED')
}
