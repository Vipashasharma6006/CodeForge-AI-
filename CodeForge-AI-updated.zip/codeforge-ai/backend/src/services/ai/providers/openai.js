/**
 * Placeholder provider for OpenAI — implement the same interface as
 * gemini.js to enable it: async generate({ prompt, temperature, maxTokens,
 * apiKey, model }) -> string
 *
 * To wire this up for real:
 *   1. npm install openai
 *   2. Add OPENAI_API_KEY / OPENAI_MODEL to .env and env.js
 *   3. Implement generate() using the OpenAI SDK's chat.completions.create
 *   4. Register it in ./index.js
 */
import { AIServiceError } from '../../../utils/AppError.js'

export async function generate() {
  throw new AIServiceError('OpenAI provider is not yet configured on this server.', 501, 'AI_PROVIDER_NOT_IMPLEMENTED')
}
