/**
 * Gemini provider — implements the common provider interface:
 *   async function generate({ prompt, temperature, maxTokens }) -> string
 *
 * Uses the official Google Gen AI SDK (@google/genai), which replaced the
 * deprecated @google/generative-ai package. See:
 *   https://github.com/googleapis/js-genai
 */
import { GoogleGenAI } from '@google/genai'
import { AIServiceError } from '../../../utils/AppError.js'
import { logger } from '../../../utils/logger.js'

let client = null
let cachedKey = null

function getClient(apiKey) {
  // Recreate the client only if the key actually changes (tests, key rotation).
  if (!client || cachedKey !== apiKey) {
    client = new GoogleGenAI({ apiKey })
    cachedKey = apiKey
  }
  return client
}

/**
 * Normalizes any error thrown by the SDK (network failure, invalid key,
 * rate limit, model unavailable, etc.) into an AIServiceError with a
 * client-safe message and an appropriate HTTP status code.
 */
function normalizeError(err) {
  const status = err?.status ?? err?.code

  // Network-level failures (DNS, connection refused, fetch aborted) —
  // the SDK/underlying fetch throws these without an HTTP status.
  if (!status) {
    const isNetworkError =
      err?.name === 'FetchError' ||
      err?.cause?.code === 'ENOTFOUND' ||
      err?.cause?.code === 'ECONNREFUSED' ||
      err?.message?.toLowerCase().includes('fetch failed') ||
      err?.message?.toLowerCase().includes('network')

    if (isNetworkError) {
      return new AIServiceError(
        'Could not reach the Gemini API. Please check your network connection and try again.',
        503,
        'AI_NETWORK_ERROR'
      )
    }
    return new AIServiceError('Unexpected error while contacting the AI provider.', 500, 'AI_UNKNOWN_ERROR')
  }

  switch (status) {
    case 400:
      return new AIServiceError('The AI request was malformed or the input was rejected by the provider.', 400, 'AI_BAD_REQUEST')
    case 401:
    case 403:
      return new AIServiceError('The Gemini API key is invalid, expired, or lacks permission.', 401, 'AI_INVALID_KEY')
    case 404:
      return new AIServiceError('The requested Gemini model is unavailable. Check GEMINI_MODEL in your .env.', 404, 'AI_MODEL_UNAVAILABLE')
    case 429:
      return new AIServiceError('Gemini API rate limit or quota exceeded. Please try again shortly.', 429, 'AI_RATE_LIMITED')
    case 500:
    case 503:
      return new AIServiceError('The Gemini API is temporarily unavailable. Please try again shortly.', 503, 'AI_PROVIDER_DOWN')
    default:
      return new AIServiceError('The AI provider returned an error.', 502, 'AI_PROVIDER_ERROR')
  }
}

export async function generate({ prompt, temperature = 0.7, maxTokens = 2048, apiKey, model }) {
  if (!apiKey) {
    throw new AIServiceError('Gemini API key is not configured on the server.', 401, 'AI_MISSING_KEY')
  }

  try {
    const ai = getClient(apiKey)
    const response = await ai.models.generateContent({
      model: model || 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature,
        maxOutputTokens: maxTokens,
      },
    })

    const text = response?.text
    if (!text || !text.trim()) {
      throw new AIServiceError('The AI model returned an empty response. Please try again.', 502, 'AI_EMPTY_RESPONSE')
    }
    return text
  } catch (err) {
    if (err instanceof AIServiceError) throw err
    logger.error('Gemini API call failed', { name: err?.name, message: err?.message, status: err?.status })
    throw normalizeError(err)
  }
}
