/**
 * Placeholder provider for Anthropic Claude — same interface as gemini.js.
 *
 * To wire this up for real:
 *   1. npm install @anthropic-ai/sdk
 *   2. Add ANTHROPIC_API_KEY / ANTHROPIC_MODEL to .env and env.js
 *   3. Implement generate() using client.messages.create(...)
 *   4. Register it in ./index.js
 */
import { AIServiceError } from '../../../utils/AppError.js'

export async function generate() {
  throw new AIServiceError('Claude provider is not yet configured on this server.', 501, 'AI_PROVIDER_NOT_IMPLEMENTED')
}
