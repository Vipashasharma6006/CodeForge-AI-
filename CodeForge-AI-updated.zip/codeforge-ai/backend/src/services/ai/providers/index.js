/**
 * Provider registry. Adding a new AI provider is: write a module that
 * exports `generate({ prompt, temperature, maxTokens, apiKey, model })`,
 * then add one line here. Nothing else in the codebase needs to change.
 */
import * as gemini from './gemini.js'
import * as openai from './openai.js'
import * as claude from './claude.js'
import * as groq from './groq.js'

export const providers = {
  gemini,
  openai,
  claude,
  groq,
}

export function getProvider(name) {
  const provider = providers[name]
  if (!provider) {
    throw new Error(`Unknown AI provider "${name}". Available: ${Object.keys(providers).join(', ')}`)
  }
  return provider
}
