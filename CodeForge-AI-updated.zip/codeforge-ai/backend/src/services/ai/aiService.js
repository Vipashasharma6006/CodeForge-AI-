/**
 * AI Service — orchestrates prompt building + provider calls, and falls
 * back to demo/mock responses when no API key is configured.
 *
 * Design:
 *  - Prompt construction lives in ./prompts.js (pure functions, no I/O).
 *  - Provider API calls live in ./providers/*.js (one file per provider,
 *    all implementing the same generate() signature).
 *  - This file just wires the two together per "mode" (review/debug/etc),
 *    so adding a new AI operation or a new provider never requires
 *    touching both concerns at once.
 */
import { getProvider } from './providers/index.js'
import { mockReviews, mockChatReply } from './mockResponses.js'
import {
  buildReviewPrompt,
  buildDebugPrompt,
  buildOptimizePrompt,
  buildExplainPrompt,
  buildChatPrompt,
} from './prompts.js'

/**
 * Returns { configured, provider, model } describing the active AI setup,
 * without ever exposing the API key itself.
 */
export function getAIStatus(env) {
  return {
    configured: Boolean(env.geminiApiKey),
    provider: env.aiProvider,
    model: env.geminiModel,
  }
}

async function runProvider(env, prompt) {
  const provider = getProvider(env.aiProvider)
  return provider.generate({
    prompt,
    apiKey: env.geminiApiKey,
    model: env.geminiModel,
  })
}

export async function reviewCode({ code, language }, env) {
  if (!env.geminiApiKey) return mockReviews.review(code, language)
  return runProvider(env, buildReviewPrompt({ code, language }))
}

export async function debugCode({ code, language, error }, env) {
  if (!env.geminiApiKey) return mockReviews.debug(code)
  return runProvider(env, buildDebugPrompt({ code, language, error }))
}

export async function optimizeCode({ code, language }, env) {
  if (!env.geminiApiKey) return mockReviews.optimize(code)
  return runProvider(env, buildOptimizePrompt({ code, language }))
}

export async function explainCode({ code, language }, env) {
  if (!env.geminiApiKey) return mockReviews.explain(code)
  return runProvider(env, buildExplainPrompt({ code, language }))
}

export async function chatWithAI({ message, code, language, history }, env) {
  if (!env.geminiApiKey) return mockChatReply(message)
  return runProvider(env, buildChatPrompt({ message, code, language, history }))
}
