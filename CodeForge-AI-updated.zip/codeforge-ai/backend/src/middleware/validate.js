/**
 * Runs an array of express-validator checks, then turns any failures into
 * a single ValidationError (400) with details — instead of every route
 * hand-rolling its own `if (!field) return res.status(400)...` checks.
 */
import { validationResult } from 'express-validator'
import { ValidationError } from '../utils/AppError.js'

export function validate(checks) {
  return async function runValidation(req, res, next) {
    for (const check of checks) {
      // eslint-disable-next-line no-await-in-loop
      await check.run(req)
    }

    const result = validationResult(req)
    if (result.isEmpty()) return next()

    const details = result.array({ onlyFirstError: true }).map(e => ({
      field: e.path,
      message: e.msg,
    }))
    next(new ValidationError('Request validation failed', details))
  }
}
