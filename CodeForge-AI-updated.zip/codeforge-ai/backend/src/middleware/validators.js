import { body, param, query } from 'express-validator'
import { MAX_CODE_LENGTH, MAX_MESSAGE_LENGTH } from '../services/ai/prompts.js'

export const VALID_LANGUAGES = ['javascript', 'python', 'cpp', 'c', 'java', 'go']

export const codeField = body('code')
  .exists({ checkFalsy: true }).withMessage('code is required')
  .bail()
  .isString().withMessage('code must be a string')
  .isLength({ max: MAX_CODE_LENGTH }).withMessage(`code must be ${MAX_CODE_LENGTH} characters or fewer`)

export const languageField = body('language')
  .optional()
  .isString()
  .isIn(VALID_LANGUAGES).withMessage(`language must be one of: ${VALID_LANGUAGES.join(', ')}`)

export const messageField = body('message')
  .exists({ checkFalsy: true }).withMessage('message is required')
  .bail()
  .isString().withMessage('message must be a string')
  .isLength({ max: MAX_MESSAGE_LENGTH }).withMessage(`message must be ${MAX_MESSAGE_LENGTH} characters or fewer`)

export const registerValidators = [
  body('username').exists({ checkFalsy: true }).withMessage('username is required')
    .bail().isString().trim().isLength({ min: 3, max: 30 }).withMessage('username must be 3-30 characters')
    .matches(/^[a-zA-Z0-9_.-]+$/).withMessage('username may only contain letters, numbers, underscores, dots and dashes'),
  body('email').exists({ checkFalsy: true }).withMessage('email is required')
    .bail().isEmail().withMessage('a valid email is required').normalizeEmail(),
  body('password').exists({ checkFalsy: true }).withMessage('password is required')
    .bail().isString().isLength({ min: 6, max: 128 }).withMessage('password must be 6-128 characters'),
]

export const loginValidators = [
  body('email').exists({ checkFalsy: true }).withMessage('email is required').bail().isEmail().normalizeEmail(),
  body('password').exists({ checkFalsy: true }).withMessage('password is required').bail().isString(),
]

export const aiChatValidators = [messageField, body('code').optional().isString().isLength({ max: MAX_CODE_LENGTH }), languageField]
export const aiCodeValidators = [codeField, languageField]
export const runCodeValidators = [codeField, languageField]

export const executeCodeValidators = [
  codeField,
  body('language').optional().isString().isIn(VALID_LANGUAGES),
  body('problemId').optional().isString().isLength({ max: 100 }),
]

export const submitValidators = [codeField, languageField]

export const problemsQueryValidators = [
  query('difficulty').optional().isString().isLength({ max: 30 }),
  query('tag').optional().isString().isLength({ max: 50 }),
  query('search').optional().isString().isLength({ max: 100 }),
  query('page').optional().isInt({ min: 1 }).toInt(),
  query('limit').optional().isInt({ min: 1, max: 100 }).toInt(),
]

export const problemIdParamValidator = [param('id').isString().isLength({ min: 1, max: 100 })]
