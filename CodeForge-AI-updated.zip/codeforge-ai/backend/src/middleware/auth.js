import jwt from 'jsonwebtoken'
import { AuthError } from '../utils/AppError.js'

export function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next(new AuthError('No token provided'))
  }
  const token = authHeader.split(' ')[1]
  try {
    const secret = req.app.locals.env?.jwtSecret || process.env.JWT_SECRET
    req.user = jwt.verify(token, secret)
    next()
  } catch {
    next(new AuthError('Invalid or expired token'))
  }
}

export function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1]
    try {
      const secret = req.app.locals.env?.jwtSecret || process.env.JWT_SECRET
      req.user = jwt.verify(token, secret)
    } catch {
      // Invalid/expired token on an optional-auth route: proceed as anonymous
      // rather than failing the request.
    }
  }
  next()
}
