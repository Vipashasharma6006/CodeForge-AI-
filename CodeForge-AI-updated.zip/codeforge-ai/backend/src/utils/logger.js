/**
 * Minimal structured logger. Two goals:
 *  1. One place to control log formatting/level.
 *  2. Guarantee secrets (API keys, JWT secret, Authorization headers)
 *     never reach stdout/stderr, even if someone accidentally logs an
 *     error object or request body that contains one.
 */

const SECRET_KEYS = ['gemini_api_key', 'apikey', 'api_key', 'authorization', 'jwt_secret', 'password', 'token']

function redact(value) {
  if (value == null) return value

  if (typeof value === 'string') {
    // Redact anything that looks like a bearer token or long API-key-ish string
    return value.replace(/Bearer\s+[\w-]+\.[\w-]+\.[\w-]+/gi, 'Bearer [REDACTED]')
  }

  if (Array.isArray(value)) return value.map(redact)

  if (typeof value === 'object') {
    const clone = {}
    for (const [key, val] of Object.entries(value)) {
      if (SECRET_KEYS.includes(key.toLowerCase())) {
        clone[key] = '[REDACTED]'
      } else {
        clone[key] = redact(val)
      }
    }
    return clone
  }

  return value
}

function timestamp() {
  return new Date().toISOString()
}

export const logger = {
  info(message, meta) {
    console.log(`[${timestamp()}] INFO  ${message}`, meta ? redact(meta) : '')
  },
  warn(message, meta) {
    console.warn(`[${timestamp()}] WARN  ${message}`, meta ? redact(meta) : '')
  },
  error(message, meta) {
    console.error(`[${timestamp()}] ERROR ${message}`, meta ? redact(meta) : '')
  },
}

export { redact }
