/**
 * Wraps an async Express route handler so any rejected promise or thrown
 * error is forwarded to next(err) automatically, instead of every route
 * needing its own try/catch block. This is what actually fixes the
 * "unhandled promise rejection" risk that existed when async route
 * handlers threw before their try/catch (or omitted one entirely).
 *
 * Usage:
 *   router.post('/thing', asyncHandler(async (req, res) => { ... }))
 */
export function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next)
  }
}
