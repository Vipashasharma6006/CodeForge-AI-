/**
 * Centralized application error types.
 *
 * Every operational error thrown anywhere in the backend should be an
 * instance of AppError (or a subclass) so the global error handler in
 * server.js can map it to the correct HTTP status code and a safe,
 * consistent JSON body — without leaking stack traces or internal details
 * to the client.
 */

export class AppError extends Error {
  constructor(message, statusCode = 500, code = 'INTERNAL_ERROR', details = undefined) {
    super(message)
    this.name = this.constructor.name
    this.statusCode = statusCode
    this.code = code
    this.details = details
    this.isOperational = true
    Error.captureStackTrace?.(this, this.constructor)
  }
}

/** 400 — request body/query failed validation */
export class ValidationError extends AppError {
  constructor(message = 'Invalid request', details = undefined) {
    super(message, 400, 'VALIDATION_ERROR', details)
  }
}

/** 401 — missing/invalid credentials or token */
export class AuthError extends AppError {
  constructor(message = 'Authentication failed') {
    super(message, 401, 'AUTH_ERROR')
  }
}

/** 404 — resource not found */
export class NotFoundError extends AppError {
  constructor(message = 'Resource not found') {
    super(message, 404, 'NOT_FOUND')
  }
}

/** 409 — conflicting state (e.g. duplicate user) */
export class ConflictError extends AppError {
  constructor(message = 'Conflict') {
    super(message, 409, 'CONFLICT')
  }
}

/**
 * Error raised by an AI provider call (Gemini, etc). Normalizes upstream
 * errors (invalid key, rate limit, model unavailable, network failure)
 * into a single shape the routes can handle uniformly.
 */
export class AIServiceError extends AppError {
  constructor(message, statusCode = 502, code = 'AI_PROVIDER_ERROR') {
    super(message, statusCode, code)
  }
}
