import express from 'express'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { v4 as uuidv4 } from 'uuid'
import { rateLimit } from 'express-rate-limit'
import { usersDb } from '../config/db.js'
import { validate } from '../middleware/validate.js'
import { registerValidators, loginValidators } from '../middleware/validators.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { AuthError, ConflictError, NotFoundError } from '../utils/AppError.js'

const router = express.Router()

// Slow down credential-stuffing / brute-force attempts specifically on
// login and register, independent of the general API rate limiter.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' },
})

function signToken(user, env) {
  return jwt.sign(
    { id: user.id, username: user.username, email: user.email, role: user.role },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  )
}

function toSafeUser(user) {
  const { passwordHash: _passwordHash, ...safeUser } = user
  return safeUser
}

// POST /api/auth/register
router.post('/register', authLimiter, validate(registerValidators), asyncHandler(async (req, res) => {
  const { username, email, password } = req.body

  const existing = usersDb.data.users.find(
    u => u.email === email || u.username === username
  )
  if (existing) {
    throw new ConflictError('Username or email already taken')
  }

  const passwordHash = await bcrypt.hash(password, 10)
  const user = {
    id: uuidv4(),
    username,
    email,
    passwordHash,
    avatar: username.slice(0, 2).toUpperCase(),
    role: 'user',
    createdAt: new Date().toISOString(),
    stats: {
      solved: 0, attempted: 0, streak: 0, rank: 9999,
      submissions: 0, languages: {}
    }
  }

  usersDb.data.users.push(user)
  await usersDb.write()

  const token = signToken(user, req.app.locals.env)
  res.status(201).json({ token, user: toSafeUser(user) })
}))

// POST /api/auth/login
router.post('/login', authLimiter, validate(loginValidators), asyncHandler(async (req, res) => {
  const { email, password } = req.body

  const user = usersDb.data.users.find(u => u.email === email)
  if (!user) throw new AuthError('Invalid credentials')

  const valid = await bcrypt.compare(password, user.passwordHash)
  if (!valid) throw new AuthError('Invalid credentials')

  const token = signToken(user, req.app.locals.env)
  res.json({ token, user: toSafeUser(user) })
}))

// GET /api/auth/me
router.get('/me', asyncHandler(async (req, res) => {
  const authHeader = req.headers.authorization
  if (!authHeader?.startsWith('Bearer ')) {
    throw new AuthError('No token provided')
  }
  const token = authHeader.split(' ')[1]

  let decoded
  try {
    decoded = jwt.verify(token, req.app.locals.env.jwtSecret)
  } catch {
    throw new AuthError('Invalid or expired token')
  }

  const user = usersDb.data.users.find(u => u.id === decoded.id)
  if (!user) throw new NotFoundError('User not found')
  res.json(toSafeUser(user))
}))

export default router
