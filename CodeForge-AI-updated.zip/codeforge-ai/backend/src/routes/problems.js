import express from 'express'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { authMiddleware, optionalAuth } from '../middleware/auth.js'
import { validate } from '../middleware/validate.js'
import { problemsQueryValidators, problemIdParamValidator, submitValidators } from '../middleware/validators.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { NotFoundError } from '../utils/AppError.js'
import { submissionsDb, usersDb } from '../config/db.js'
import { v4 as uuidv4 } from 'uuid'
import { executeCode } from '../services/executionService.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const router = express.Router()

let problemsData = []

async function loadProblems() {
  const { readFile } = await import('fs/promises')
  const data = await readFile(join(__dirname, '../../data/problems.json'), 'utf8')
  problemsData = JSON.parse(data)
}

// Kick off the initial load; routes below guard against it not being
// finished yet by simply returning an empty list rather than crashing.
const problemsReady = loadProblems().catch(err => {
  console.error('Failed to load problems.json:', err.message)
})

// GET /api/problems
router.get('/', optionalAuth, validate(problemsQueryValidators), asyncHandler(async (req, res) => {
  await problemsReady
  const { difficulty, tag, search, page = 1, limit = 20 } = req.query

  let filtered = [...problemsData]

  if (difficulty) {
    filtered = filtered.filter(p => p.difficulty.toLowerCase() === difficulty.toLowerCase())
  }
  if (tag) {
    filtered = filtered.filter(p => p.tags.some(t => t.toLowerCase().includes(tag.toLowerCase())))
  }
  if (search) {
    filtered = filtered.filter(p =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))
    )
  }

  // Add solve status if user is logged in
  let userSolvedIds = []
  if (req.user) {
    userSolvedIds = submissionsDb.data.submissions
      .filter(s => s.userId === req.user.id && s.status === 'accepted')
      .map(s => s.problemId)
  }

  const problems = filtered.map(p => ({
    id: p.id, title: p.title, slug: p.slug, difficulty: p.difficulty,
    tags: p.tags, acceptance: p.acceptance,
    solved: userSolvedIds.includes(p.id)
  }))

  const start = (page - 1) * limit
  res.json({
    problems: problems.slice(start, start + Number(limit)),
    total: problems.length,
    page: Number(page),
    pages: Math.ceil(problems.length / limit)
  })
}))

// GET /api/problems/:id
router.get('/:id', optionalAuth, validate(problemIdParamValidator), asyncHandler(async (req, res) => {
  await problemsReady
  const problem = problemsData.find(p => p.id === req.params.id || p.slug === req.params.id)
  if (!problem) throw new NotFoundError('Problem not found')
  res.json(problem)
}))

// POST /api/problems/:id/submit — run against test cases
router.post('/:id/submit', authMiddleware, validate([...problemIdParamValidator, ...submitValidators]), asyncHandler(async (req, res) => {
  await problemsReady
  const problem = problemsData.find(p => p.id === req.params.id || p.slug === req.params.id)
  if (!problem) throw new NotFoundError('Problem not found')

  const { code, language = 'javascript' } = req.body

  // Execute the code
  const result = await executeCode({ code, language })

  // Run test cases for problems that have them
  const testResults = []
  let passed = 0
  const total = problem.testCases?.length || 0

  if (total > 0 && language === 'javascript') {
    for (const tc of problem.testCases) {
      try {
        // Inject test case and evaluate
        const testCode = `
${code}
const __input = ${JSON.stringify(tc.input)};
let __result;
// Try different function signatures
try {
  if (typeof twoSum === 'function') __result = twoSum(__input.nums || [], __input.target || 0);
  else if (typeof maxSubArray === 'function') __result = maxSubArray(__input.nums || []);
  else if (typeof isValid === 'function') __result = isValid(__input.s || '');
  else __result = null;
} catch(e) { __result = null; }
console.log(JSON.stringify(__result));`

        const tcResult = await executeCode({ code: testCode, language: 'javascript' })
        let output
        try { output = JSON.parse(tcResult.stdout.trim()) } catch { output = tcResult.stdout.trim() }
        const correct = JSON.stringify(output) === JSON.stringify(tc.expected)
        if (correct) passed++
        testResults.push({
          input: JSON.stringify(tc.input),
          expected: JSON.stringify(tc.expected),
          output: JSON.stringify(output),
          passed: correct,
          runtime: tcResult.runtime
        })
      } catch {
        testResults.push({ passed: false, error: 'Execution error' })
      }
    }
  }

  const status = total === 0 || language !== 'javascript'
    ? (result.exitCode === 0 ? 'accepted' : 'runtime_error')
    : (passed === total ? 'accepted' : 'wrong_answer')

  const submission = {
    id: uuidv4(),
    userId: req.user.id,
    problemId: problem.id,
    problemTitle: problem.title,
    code, language, status,
    result, testResults,
    passed, total,
    createdAt: new Date().toISOString()
  }

  submissionsDb.data.submissions.push(submission)
  try { submissionsDb.write() } catch { /* best-effort persistence */ }

  // Update user stats
  const user = usersDb.data.users.find(u => u.id === req.user.id)
  if (user) {
    user.stats.submissions = (user.stats.submissions || 0) + 1
    user.stats.languages = user.stats.languages || {}
    user.stats.languages[language] = (user.stats.languages[language] || 0) + 1
    if (status === 'accepted') {
      user.stats.solved = (user.stats.solved || 0) + 1
    }
    try { usersDb.write() } catch { /* best-effort persistence */ }
  }

  res.json({ submissionId: submission.id, status, passed, total, testResults, result })
}))

export default router
