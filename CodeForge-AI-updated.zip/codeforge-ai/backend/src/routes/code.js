import express from 'express'
import { v4 as uuidv4 } from 'uuid'
import { authMiddleware } from '../middleware/auth.js'
import { validate } from '../middleware/validate.js'
import { executeCodeValidators, runCodeValidators } from '../middleware/validators.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { NotFoundError } from '../utils/AppError.js'
import { executionQueue } from '../services/queueService.js'
import { executeCode } from '../services/executionService.js'
import { submissionsDb } from '../config/db.js'

const router = express.Router()

// POST /api/code/execute — execute code, queue it, return job ID
router.post('/execute', authMiddleware, validate(executeCodeValidators), asyncHandler(async (req, res) => {
  const { code, language = 'javascript', problemId } = req.body
  const job = await executionQueue.add({ code, language, problemId, userId: req.user.id })
  res.json({ jobId: job.id, status: 'queued', message: 'Code queued for execution' })
}))

// GET /api/code/status/:jobId — poll execution result
router.get('/status/:jobId', authMiddleware, asyncHandler(async (req, res) => {
  const job = await executionQueue.getJob(req.params.jobId)
  if (!job) throw new NotFoundError('Job not found')

  if (job.status === 'completed') {
    return res.json({ status: 'completed', result: job.result })
  }
  if (job.status === 'failed') {
    return res.json({ status: 'failed', error: job.error })
  }
  res.json({ status: job.status, progress: job.progress })
}))

// POST /api/code/run — synchronous execution (for quick run button)
router.post('/run', authMiddleware, validate(runCodeValidators), asyncHandler(async (req, res) => {
  const { code, language = 'javascript' } = req.body
  const result = await executeCode({ code, language })

  const submission = {
    id: uuidv4(),
    userId: req.user.id,
    code, language,
    type: 'run',
    result,
    createdAt: new Date().toISOString()
  }
  submissionsDb.data.submissions.push(submission)
  try {
    submissionsDb.write()
  } catch (err) {
    // Submission logging is best-effort — a disk write failure shouldn't
    // fail the user's code execution response.
    req.app.locals.logger?.warn('Failed to persist submission', { message: err.message })
  }

  res.json(result)
}))

// GET /api/code/submissions — user's submission history
router.get('/submissions', authMiddleware, asyncHandler(async (req, res) => {
  const userSubmissions = submissionsDb.data.submissions
    .filter(s => s.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 50)
  res.json(userSubmissions)
}))

// GET /api/code/queue/stats
router.get('/queue/stats', authMiddleware, asyncHandler(async (req, res) => {
  const stats = await executionQueue.getStats()
  res.json(stats)
}))

export default router
