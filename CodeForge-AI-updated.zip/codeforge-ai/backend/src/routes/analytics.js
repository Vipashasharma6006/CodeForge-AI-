import express from 'express'
import { authMiddleware } from '../middleware/auth.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { NotFoundError } from '../utils/AppError.js'
import { usersDb, submissionsDb } from '../config/db.js'

const router = express.Router()

// GET /api/analytics/me — current user analytics
router.get('/me', authMiddleware, asyncHandler(async (req, res) => {
  const user = usersDb.data.users.find(u => u.id === req.user.id)
  if (!user) throw new NotFoundError('User not found')

  const submissions = submissionsDb.data.submissions.filter(s => s.userId === req.user.id)

  // Build activity heatmap (last 52 weeks)
  const heatmap = {}
  submissions.forEach(s => {
    const date = s.createdAt.slice(0, 10)
    heatmap[date] = (heatmap[date] || 0) + 1
  })

  // Language distribution
  const langDist = {}
  submissions.forEach(s => {
    langDist[s.language] = (langDist[s.language] || 0) + 1
  })

  // Status distribution
  const statusDist = { accepted: 0, wrong_answer: 0, runtime_error: 0, run: 0 }
  submissions.forEach(s => {
    const key = s.status || s.type || 'run'
    statusDist[key] = (statusDist[key] || 0) + 1
  })

  // Recent submissions
  const recent = submissions
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 10)
    .map(s => ({
      id: s.id,
      problemTitle: s.problemTitle || 'Quick Run',
      language: s.language,
      status: s.status || s.type,
      runtime: s.result?.runtime,
      createdAt: s.createdAt
    }))

  // Streak calculation
  const uniqueDays = [...new Set(submissions.map(s => s.createdAt.slice(0, 10)))].sort().reverse()
  let streak = 0
  const today = new Date().toISOString().slice(0, 10)
  let checkDate = today
  for (const d of uniqueDays) {
    if (d === checkDate) {
      streak++
      const dt = new Date(checkDate)
      dt.setDate(dt.getDate() - 1)
      checkDate = dt.toISOString().slice(0, 10)
    } else break
  }

  res.json({
    user: {
      username: user.username,
      avatar: user.avatar,
      rank: user.stats.rank,
      joined: user.createdAt
    },
    stats: {
      solved: user.stats.solved || 0,
      attempted: submissions.filter(s => s.type === 'submit' || s.problemId).length,
      submissions: submissions.length,
      streak,
      acceptanceRate: submissions.length > 0
        ? Math.round((statusDist.accepted / (submissions.length || 1)) * 100)
        : 0
    },
    heatmap,
    languageDistribution: langDist,
    statusDistribution: statusDist,
    recentSubmissions: recent
  })
}))

// GET /api/analytics/leaderboard
router.get('/leaderboard', asyncHandler(async (req, res) => {
  const users = usersDb.data.users.map(u => ({
    id: u.id,
    username: u.username,
    avatar: u.avatar,
    solved: u.stats?.solved || 0,
    submissions: u.stats?.submissions || 0,
    streak: u.stats?.streak || 0,
    rank: u.stats?.rank || 9999,
    joinedAt: u.createdAt
  })).sort((a, b) => b.solved - a.solved || a.rank - b.rank)

  res.json(users.slice(0, 50))
}))

// GET /api/analytics/platform — global platform stats
router.get('/platform', asyncHandler(async (req, res) => {
  const totalUsers = usersDb.data.users.length
  const totalSubmissions = submissionsDb.data.submissions.length
  const langTotals = {}
  submissionsDb.data.submissions.forEach(s => {
    langTotals[s.language] = (langTotals[s.language] || 0) + 1
  })

  res.json({
    totalUsers,
    totalSubmissions,
    activeToday: Math.floor(totalUsers * 0.3),
    languageTotals: langTotals,
    problemsAvailable: 6
  })
}))

export default router
