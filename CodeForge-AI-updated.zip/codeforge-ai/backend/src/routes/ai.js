import express from 'express'
import { rateLimit } from 'express-rate-limit'
import { authMiddleware } from '../middleware/auth.js'
import { validate } from '../middleware/validate.js'
import { aiChatValidators, aiCodeValidators } from '../middleware/validators.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { reviewCode, debugCode, optimizeCode, explainCode, chatWithAI, getAIStatus } from '../services/ai/aiService.js'

const router = express.Router()

// AI calls hit a paid, rate-limited upstream API — cap usage separately
// and more tightly than the general API limiter.
const aiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many AI requests. Please wait a few minutes and try again.' },
})
router.use(aiLimiter)

function getEnv(req) {
  return req.app.locals.env
}

router.post('/review', authMiddleware, validate(aiCodeValidators), asyncHandler(async (req, res) => {
  const { code, language = 'javascript' } = req.body
  const env = getEnv(req)
  const result = await reviewCode({ code, language }, env)
  res.json({ result, mode: getAIStatus(env).configured ? 'gemini' : 'demo' })
}))

router.post('/debug', authMiddleware, validate(aiCodeValidators), asyncHandler(async (req, res) => {
  const { code, language = 'javascript', error } = req.body
  const env = getEnv(req)
  const result = await debugCode({ code, language, error }, env)
  res.json({ result, mode: getAIStatus(env).configured ? 'gemini' : 'demo' })
}))

router.post('/optimize', authMiddleware, validate(aiCodeValidators), asyncHandler(async (req, res) => {
  const { code, language = 'javascript' } = req.body
  const env = getEnv(req)
  const result = await optimizeCode({ code, language }, env)
  res.json({ result, mode: getAIStatus(env).configured ? 'gemini' : 'demo' })
}))

router.post('/explain', authMiddleware, validate(aiCodeValidators), asyncHandler(async (req, res) => {
  const { code, language = 'javascript' } = req.body
  const env = getEnv(req)
  const result = await explainCode({ code, language }, env)
  res.json({ result, mode: getAIStatus(env).configured ? 'gemini' : 'demo' })
}))

router.post('/chat', authMiddleware, validate(aiChatValidators), asyncHandler(async (req, res) => {
  const { message, code, language, history } = req.body
  const env = getEnv(req)
  const result = await chatWithAI({ message, code, language, history }, env)
  res.json({ result, mode: getAIStatus(env).configured ? 'gemini' : 'demo' })
}))

// GET /api/ai/status — lets the frontend show "AI: connected/demo" without
// ever exposing the key itself.
router.get('/status', (req, res) => {
  res.json(getAIStatus(getEnv(req)))
})

export default router
