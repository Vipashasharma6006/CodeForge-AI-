import 'dotenv/config'
import express from 'express'
import { createServer } from 'http'
import { Server } from 'socket.io'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import { rateLimit } from 'express-rate-limit'

import { validateEnv } from './src/config/env.js'
import { logger } from './src/utils/logger.js'
import { AppError } from './src/utils/AppError.js'
import { initDB } from './src/config/db.js'
import { initExecutionService } from './src/services/executionService.js'
import { executionQueue } from './src/services/queueService.js'
import { executeCode } from './src/services/executionService.js'
import { setupCollaboration } from './src/socket/collaborationHandler.js'
import { getAIStatus } from './src/services/ai/aiService.js'

import authRoutes from './src/routes/auth.js'
import codeRoutes from './src/routes/code.js'
import problemsRoutes from './src/routes/problems.js'
import aiRoutes from './src/routes/ai.js'
import analyticsRoutes from './src/routes/analytics.js'

// ─── Environment ────────────────────────────────────────────────────────────
// Fails fast with a clear message if required config is missing, instead of
// booting into a broken state.
let env
try {
  env = validateEnv()
} catch (err) {
  logger.error(err.message)
  process.exit(1)
}

const app = express()
const httpServer = createServer(app)

// CORS origin is configurable via CORS_ORIGIN (comma-separated list).
// Defaults to '*' for easy local/demo use; set it explicitly in production
// once the frontend's real deployed origin is known.
const corsOrigins = env.corsOrigin === '*' ? '*' : env.corsOrigin.split(',').map(o => o.trim())

const io = new Server(httpServer, {
  cors: { origin: corsOrigins, methods: ['GET', 'POST'] }
})

// Make shared config available to every route via req.app.locals, so
// nothing needs to reach into process.env directly (and secrets stay in
// one, easily-audited place).
app.locals.env = env
app.locals.logger = logger

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({ origin: corsOrigins }))
app.use(helmet({ contentSecurityPolicy: false }))
app.use(morgan(env.nodeEnv === 'production' ? 'combined' : 'dev'))
app.use(express.json({ limit: '2mb' }))

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200, standardHeaders: true, legacyHeaders: false })
app.use('/api/', limiter)

const executionLimiter = rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false })
app.use('/api/code/', executionLimiter)

// ─── Routes ──────────────────────────────────────────────────────────────────
app.use('/api/auth', authRoutes)
app.use('/api/code', codeRoutes)
app.use('/api/problems', problemsRoutes)
app.use('/api/ai', aiRoutes)
app.use('/api/analytics', analyticsRoutes)

// Health check — reports AI mode as a boolean only; never exposes the key.
app.get('/api/health', (req, res) => {
  const aiStatus = getAIStatus(env)
  res.json({
    status: 'ok',
    version: '1.0.0',
    platform: 'CodeForge AI',
    aiMode: aiStatus.configured ? aiStatus.provider : 'demo',
    executionMode: 'process-based',
    timestamp: new Date().toISOString()
  })
})

// 404 handler
app.use((req, res) => res.status(404).json({ error: 'Route not found' }))

// ─── Centralized error handler ────────────────────────────────────────────────
// Every route either throws/passes an AppError subclass (correct status +
// safe message) or an unexpected error, which we log in full server-side
// but never expose to the client beyond a generic message.
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof AppError) {
    logger.warn(`${err.code}: ${err.message}`, { path: req.path, details: err.details })
    return res.status(err.statusCode).json({
      error: err.message,
      code: err.code,
      ...(err.details ? { details: err.details } : {}),
    })
  }

  logger.error('Unhandled error', { path: req.path, message: err.message, stack: err.stack })
  res.status(500).json({
    error: env.nodeEnv === 'production' ? 'Internal server error' : err.message,
    code: 'INTERNAL_ERROR',
  })
})

// ─── Process-level safety nets ────────────────────────────────────────────────
// Without these, an unhandled rejection anywhere (e.g. a stray promise not
// wired through asyncHandler) silently crashes the process in newer Node
// versions, or leaves it in an undefined state in older ones.
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection', { reason: reason?.message || String(reason) })
})
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception — shutting down', { message: err.message, stack: err.stack })
  process.exit(1)
})

// ─── Queue Worker ─────────────────────────────────────────────────────────────
executionQueue.process(async (job) => {
  const { code, language } = job.data
  job.updateProgress(10)
  const result = await executeCode({ code, language })
  job.updateProgress(100)
  return result
})

// ─── Socket.IO ────────────────────────────────────────────────────────────────
setupCollaboration(io)

// ─── Startup ─────────────────────────────────────────────────────────────────
async function start() {
  await initDB()
  await initExecutionService()

  httpServer.listen(env.port, () => {
    const aiStatus = getAIStatus(env)
    console.log(`
╔══════════════════════════════════════════════════╗
║          CodeForge AI — Backend Server           ║
╠══════════════════════════════════════════════════╣
║  🚀  Server:    http://localhost:${env.port}            ║
║  🤖  AI Mode:   ${aiStatus.configured ? `${aiStatus.provider} (${aiStatus.model})`.padEnd(24) : 'Demo Mode (Mock)       '} ║
║  ⚡  Execution: Process-based (Docker-ready)    ║
║  🔌  WebSocket: Socket.IO active                ║
║  💾  Database:  JSON file store (embedded)      ║
╠══════════════════════════════════════════════════╣
║  API Endpoints:                                  ║
║    POST /api/auth/register                       ║
║    POST /api/auth/login                          ║
║    POST /api/code/run                            ║
║    GET  /api/problems                            ║
║    POST /api/ai/review                           ║
║    GET  /api/analytics/me                        ║
╚══════════════════════════════════════════════════╝
    `)
  })
}

start().catch(err => {
  logger.error('Fatal startup error', { message: err.message, stack: err.stack })
  process.exit(1)
})
